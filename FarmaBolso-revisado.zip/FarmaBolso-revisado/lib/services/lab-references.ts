/**
 * Valores de referência para exames laboratoriais comuns
 * Fonte: Sociedades médicas brasileiras e protocolos internacionais
 */

export interface LabReference {
  id: string;
  name: string;
  category: 'hematology' | 'biochemistry' | 'lipids' | 'thyroid' | 'liver' | 'kidney' | 'urine';
  unit: string;
  description: string;
  reference: {
    male: { min: number; max: number };
    female: { min: number; max: number };
  };
  interpretation: {
    low: string;
    normal: string;
    high: string;
  };
}

export const labReferences: LabReference[] = [
  // Hematology
  {
    id: 'hemoglobin',
    name: 'Hemoglobina',
    category: 'hematology',
    unit: 'g/dL',
    description: 'Proteína que transporta oxigênio no sangue',
    reference: {
      male: { min: 13.5, max: 17.5 },
      female: { min: 12.0, max: 15.5 },
    },
    interpretation: {
      low: 'Anemia - pode causar fraqueza e fadiga',
      normal: 'Nível normal de hemoglobina',
      high: 'Policitemia - aumento de glóbulos vermelhos',
    },
  },
  {
    id: 'hematocrit',
    name: 'Hematócrito',
    category: 'hematology',
    unit: '%',
    description: 'Percentual de glóbulos vermelhos no sangue',
    reference: {
      male: { min: 40, max: 54 },
      female: { min: 36, max: 46 },
    },
    interpretation: {
      low: 'Anemia - redução de glóbulos vermelhos',
      normal: 'Nível normal de hematócrito',
      high: 'Desidratação ou policitemia',
    },
  },
  {
    id: 'wbc',
    name: 'Leucócitos (Glóbulos Brancos)',
    category: 'hematology',
    unit: '×10³/μL',
    description: 'Células de defesa do corpo',
    reference: {
      male: { min: 4.5, max: 11.0 },
      female: { min: 4.5, max: 11.0 },
    },
    interpretation: {
      low: 'Imunodeficiência - risco de infecções',
      normal: 'Nível normal de defesa',
      high: 'Infecção ou inflamação',
    },
  },
  {
    id: 'platelets',
    name: 'Plaquetas',
    category: 'hematology',
    unit: '×10³/μL',
    description: 'Células responsáveis pela coagulação',
    reference: {
      male: { min: 150, max: 400 },
      female: { min: 150, max: 400 },
    },
    interpretation: {
      low: 'Risco de sangramento',
      normal: 'Coagulação normal',
      high: 'Risco de trombose',
    },
  },

  // Biochemistry
  {
    id: 'glucose_fasting',
    name: 'Glicemia de Jejum',
    category: 'biochemistry',
    unit: 'mg/dL',
    description: 'Nível de açúcar no sangue após 8-12h de jejum',
    reference: {
      male: { min: 70, max: 99 },
      female: { min: 70, max: 99 },
    },
    interpretation: {
      low: 'Hipoglicemia - risco de desmaio',
      normal: 'Glicemia normal',
      high: 'Pré-diabetes (100-125) ou Diabetes (≥126)',
    },
  },
  {
    id: 'creatinine',
    name: 'Creatinina',
    category: 'kidney',
    unit: 'mg/dL',
    description: 'Indicador de função renal',
    reference: {
      male: { min: 0.7, max: 1.3 },
      female: { min: 0.6, max: 1.1 },
    },
    interpretation: {
      low: 'Raro - pode indicar desnutrição',
      normal: 'Função renal normal',
      high: 'Insuficiência renal - procure médico',
    },
  },
  {
    id: 'urea',
    name: 'Ureia',
    category: 'kidney',
    unit: 'mg/dL',
    description: 'Produto do metabolismo proteico',
    reference: {
      male: { min: 7, max: 20 },
      female: { min: 7, max: 20 },
    },
    interpretation: {
      low: 'Desnutrição ou doença hepática',
      normal: 'Nível normal',
      high: 'Insuficiência renal ou desidratação',
    },
  },

  // Lipids
  {
    id: 'cholesterol_total',
    name: 'Colesterol Total',
    category: 'lipids',
    unit: 'mg/dL',
    description: 'Colesterol total no sangue',
    reference: {
      male: { min: 0, max: 200 },
      female: { min: 0, max: 200 },
    },
    interpretation: {
      low: 'Raro - pode indicar desnutrição',
      normal: 'Desejável (<200)',
      high: 'Risco de doença cardiovascular',
    },
  },
  {
    id: 'ldl',
    name: 'Colesterol LDL',
    category: 'lipids',
    unit: 'mg/dL',
    description: 'Colesterol ruim - transporta lipídios para artérias',
    reference: {
      male: { min: 0, max: 130 },
      female: { min: 0, max: 130 },
    },
    interpretation: {
      low: 'Muito baixo - raro',
      normal: 'Ótimo (<100) ou Desejável (100-129)',
      high: 'Aumentado (130-159) ou Alto (≥160)',
    },
  },
  {
    id: 'hdl',
    name: 'Colesterol HDL',
    category: 'lipids',
    unit: 'mg/dL',
    description: 'Colesterol bom - remove lipídios das artérias',
    reference: {
      male: { min: 40, max: 300 },
      female: { min: 50, max: 300 },
    },
    interpretation: {
      low: 'Risco de doença cardiovascular',
      normal: 'Protetor (<40 é baixo, >60 é ótimo)',
      high: 'Muito protetor',
    },
  },
  {
    id: 'triglycerides',
    name: 'Triglicerídeos',
    category: 'lipids',
    unit: 'mg/dL',
    description: 'Tipo de gordura no sangue',
    reference: {
      male: { min: 0, max: 150 },
      female: { min: 0, max: 150 },
    },
    interpretation: {
      low: 'Normal',
      normal: 'Desejável (<150)',
      high: 'Aumentado (150-199) ou Alto (≥200)',
    },
  },

  // Thyroid
  {
    id: 'tsh',
    name: 'TSH (Hormônio Estimulante da Tireoide)',
    category: 'thyroid',
    unit: 'mIU/L',
    description: 'Hormônio que regula a tireoide',
    reference: {
      male: { min: 0.4, max: 4.0 },
      female: { min: 0.4, max: 4.0 },
    },
    interpretation: {
      low: 'Hipertireoidismo - metabolismo acelerado',
      normal: 'Função tireoidiana normal',
      high: 'Hipotireoidismo - metabolismo lento',
    },
  },
  {
    id: 't4_free',
    name: 'T4 Livre',
    category: 'thyroid',
    unit: 'ng/dL',
    description: 'Hormônio tireoidiano ativo',
    reference: {
      male: { min: 0.8, max: 1.8 },
      female: { min: 0.8, max: 1.8 },
    },
    interpretation: {
      low: 'Hipotireoidismo',
      normal: 'Função tireoidiana normal',
      high: 'Hipertireoidismo',
    },
  },

  // Liver
  {
    id: 'ast',
    name: 'AST (Aspartato Aminotransferase)',
    category: 'liver',
    unit: 'U/L',
    description: 'Enzima hepática',
    reference: {
      male: { min: 10, max: 40 },
      female: { min: 7, max: 35 },
    },
    interpretation: {
      low: 'Normal',
      normal: 'Função hepática normal',
      high: 'Possível lesão hepática',
    },
  },
  {
    id: 'alt',
    name: 'ALT (Alanina Aminotransferase)',
    category: 'liver',
    unit: 'U/L',
    description: 'Enzima hepática mais específica',
    reference: {
      male: { min: 7, max: 56 },
      female: { min: 7, max: 45 },
    },
    interpretation: {
      low: 'Normal',
      normal: 'Função hepática normal',
      high: 'Possível lesão hepática',
    },
  },
];

/**
 * Medicamentos comuns e suas interações
 */
export interface MedicationInteraction {
  drug1: string;
  drug2: string;
  severity: 'low' | 'moderate' | 'high';
  description: string;
  recommendation: string;
}

export const medicationInteractions: MedicationInteraction[] = [
  {
    drug1: 'Dipirona',
    drug2: 'Ibuprofeno',
    severity: 'high',
    description: 'Ambos são anti-inflamatórios. Usar juntos aumenta risco de úlcera gástrica e problemas renais.',
    recommendation: 'Não combine. Escolha um dos dois. Consulte um médico.',
  },
  {
    drug1: 'Dipirona',
    drug2: 'Paracetamol',
    severity: 'high',
    description: 'Ambos são analgésicos. Usar juntos pode causar toxicidade hepática.',
    recommendation: 'Não combine. Escolha um dos dois.',
  },
  {
    drug1: 'Ibuprofeno',
    drug2: 'Ácido Acetilsalicílico',
    severity: 'high',
    description: 'Ambos são anti-inflamatórios. Aumenta risco de sangramento e úlcera.',
    recommendation: 'Não combine. Escolha um dos dois.',
  },
  {
    drug1: 'Metformina',
    drug2: 'Álcool',
    severity: 'moderate',
    description: 'Álcool pode aumentar risco de acidose lática com metformina.',
    recommendation: 'Evite consumo excessivo de álcool.',
  },
  {
    drug1: 'Warfarina',
    drug2: 'Ibuprofeno',
    severity: 'high',
    description: 'Ibuprofeno aumenta efeito anticoagulante da warfarina, risco de sangramento.',
    recommendation: 'Consulte médico antes de usar. Prefira paracetamol.',
  },
  {
    drug1: 'Levotiroxina',
    drug2: 'Cálcio',
    severity: 'moderate',
    description: 'Cálcio reduz absorção de levotiroxina.',
    recommendation: 'Tome levotiroxina com 4 horas de intervalo do cálcio.',
  },
  {
    drug1: 'Amoxicilina',
    drug2: 'Contraceptivo Oral',
    severity: 'moderate',
    description: 'Antibióticos podem reduzir eficácia de contraceptivos.',
    recommendation: 'Use método contraceptivo adicional durante o uso de antibiótico.',
  },
];

/**
 * Função auxiliar para obter status de um valor
 */
export function getExamStatus(
  value: number,
  reference: LabReference,
  gender: 'male' | 'female'
): 'normal' | 'low' | 'high' {
  const ref = reference.reference[gender];
  if (value < ref.min) return 'low';
  if (value > ref.max) return 'high';
  return 'normal';
}

/**
 * Função para verificar interações entre medicamentos
 */
export function checkInteractions(
  medications: string[]
): MedicationInteraction[] {
  const interactions: MedicationInteraction[] = [];

  for (let i = 0; i < medications.length; i++) {
    for (let j = i + 1; j < medications.length; j++) {
      const interaction = medicationInteractions.find(
        (inter) =>
          (inter.drug1.toLowerCase() === medications[i].toLowerCase() &&
            inter.drug2.toLowerCase() === medications[j].toLowerCase()) ||
          (inter.drug1.toLowerCase() === medications[j].toLowerCase() &&
            inter.drug2.toLowerCase() === medications[i].toLowerCase())
      );

      if (interaction) {
        interactions.push(interaction);
      }
    }
  }

  return interactions;
}
