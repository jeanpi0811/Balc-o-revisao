/**
 * Serviço para integração com a API de Bulas (bulario-api)
 * Fonte: https://github.com/iuryLandin/bulario-api
 */

const BULARIO_API_BASE = 'https://bula.vercel.app';

export interface MedicationSearchResult {
  id: string;
  processo: string;
  nomeComercial: string;
  principioAtivo: string;
  laboratorio: string;
  idBulaPacienteProtegido?: string;
  idBulaProfissionalProtegido?: string;
}

export interface MedicationDetail extends MedicationSearchResult {
  descricao: string;
  indicacoes: string;
  contraindicacoes: string;
  posologia: string;
  efeitos_colaterais: string;
}

export interface BularioCategory {
  id: string;
  nome: string;
}

/**
 * Pesquisa medicamentos por nome
 */
export async function searchMedications(
  nome: string,
  pagina: number = 1
): Promise<MedicationSearchResult[]> {
  try {
    const response = await fetch(
      `${BULARIO_API_BASE}/pesquisar?nome=${encodeURIComponent(nome)}&pagina=${pagina}`
    );

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }

    const data = await response.json();
    return data.medicamentos || [];
  } catch (error) {
    console.error('Error searching medications:', error);
    return [];
  }
}

/**
 * Obtém detalhes de um medicamento específico
 */
export async function getMedicationDetail(
  processo: string
): Promise<MedicationDetail | null> {
  try {
    const response = await fetch(
      `${BULARIO_API_BASE}/medicamento/${encodeURIComponent(processo)}`
    );

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error fetching medication detail:', error);
    return null;
  }
}

/**
 * Lista todas as categorias de medicamentos
 */
export async function getCategories(): Promise<BularioCategory[]> {
  try {
    const response = await fetch(`${BULARIO_API_BASE}/categorias`);

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }

    const data = await response.json();
    return data.categorias || [];
  } catch (error) {
    console.error('Error fetching categories:', error);
    return [];
  }
}

/**
 * Lista medicamentos por categoria
 */
export async function getMedicationsByCategory(
  categoriaId: string
): Promise<MedicationSearchResult[]> {
  try {
    const response = await fetch(
      `${BULARIO_API_BASE}/medicamentos?categoria=${encodeURIComponent(categoriaId)}`
    );

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }

    const data = await response.json();
    return data.medicamentos || [];
  } catch (error) {
    console.error('Error fetching medications by category:', error);
    return [];
  }
}

/**
 * Obtém link para download do PDF da bula
 */
export async function getBulaLink(
  idBula: string
): Promise<string | null> {
  try {
    const response = await fetch(
      `${BULARIO_API_BASE}/bula?id=${encodeURIComponent(idBula)}`
    );

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }

    const data = await response.json();
    return data.url || null;
  } catch (error) {
    console.error('Error fetching bula link:', error);
    return null;
  }
}

/**
 * Busca rápida com cache local (para melhorar performance)
 */
const searchCache = new Map<string, MedicationSearchResult[]>();

export async function searchMedicationsWithCache(
  nome: string,
  pagina: number = 1
): Promise<MedicationSearchResult[]> {
  const cacheKey = `${nome}_${pagina}`;

  if (searchCache.has(cacheKey)) {
    return searchCache.get(cacheKey) || [];
  }

  const results = await searchMedications(nome, pagina);
  searchCache.set(cacheKey, results);

  return results;
}

/**
 * Limpa o cache
 */
export function clearSearchCache(): void {
  searchCache.clear();
}
