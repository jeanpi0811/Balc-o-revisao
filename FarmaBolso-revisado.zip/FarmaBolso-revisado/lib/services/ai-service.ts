/**
 * Serviço de IA Farmacêutica
 * Usa API gratuita (DeepSeek ou similar)
 */

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

const SYSTEM_PROMPT = `Você é um assistente farmacêutico especializado. 
Sua função é fornecer informações básicas sobre medicamentos, exames laboratoriais e saúde.

IMPORTANTE:
- Respostas devem ser informativas e educacionais
- Sempre recomende consulta médica para diagnósticos ou prescrições
- Não forneça recomendações de medicamentos específicos
- Mantenha respostas concisas e claras
- Use linguagem acessível

Aviso padrão: "Esta informação é apenas educacional e não substitui orientação médica profissional. Consulte um médico para diagnóstico e tratamento."`;

/**
 * Envia mensagem para IA e obtém resposta
 * Usa API DeepSeek (gratuita) como padrão
 */
export async function sendChatMessage(
  message: string,
  conversationHistory: ChatMessage[] = []
): Promise<string> {
  try {
    // Formata histórico de conversa para a API
    const messages = [
      ...conversationHistory.map((msg) => ({
        role: msg.role,
        content: msg.content,
      })),
      {
        role: 'user' as const,
        content: message,
      },
    ];

    // Tenta usar DeepSeek API (gratuita com limite)
    // Se não tiver chave, usa resposta padrão
    const response = await fetch('https://api.deepseek.com/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.DEEPSEEK_API_KEY || ''}`,
      },
      body: JSON.stringify({
        model: 'deepseek-chat',
        messages: [
          {
            role: 'system',
            content: SYSTEM_PROMPT,
          },
          ...messages,
        ],
        temperature: 0.7,
        max_tokens: 500,
      }),
    });

    if (!response.ok) {
      // Se DeepSeek falhar, tenta resposta local
      return getLocalAIResponse(message);
    }

    const data = await response.json();
    return (
      data.choices?.[0]?.message?.content ||
      'Desculpe, não consegui processar sua pergunta.'
    );
  } catch (error) {
    console.error('Error calling AI service:', error);
    // Fallback para respostas locais
    return getLocalAIResponse(message);
  }
}

/**
 * Respostas locais de IA (sem API)
 * Útil para quando não há conexão ou API indisponível
 */
function getLocalAIResponse(message: string): string {
  const lowerMessage = message.toLowerCase();

  // Respostas sobre medicamentos comuns
  if (lowerMessage.includes('dipirona')) {
    return `Dipirona é um analgésico e antitérmico usado para febre e dor. 
Dosagem típica: 500mg a cada 6-8 horas.
Efeitos colaterais: Raro, mas pode causar reações alérgicas.
⚠️ Não combine com outros analgésicos. Consulte um médico.`;
  }

  if (lowerMessage.includes('ibuprofeno')) {
    return `Ibuprofeno é um anti-inflamatório não-esteroidal (AINE).
Usado para dor, inflamação e febre.
Dosagem típica: 200-400mg a cada 6-8 horas.
⚠️ Não use se tiver úlcera ou problemas renais. Consulte um médico.`;
  }

  if (lowerMessage.includes('paracetamol')) {
    return `Paracetamol é um analgésico e antitérmico.
Dosagem típica: 500-1000mg a cada 6 horas (máx 4g/dia).
Seguro para maioria das pessoas.
⚠️ Evite em excesso - pode danificar o fígado. Consulte um médico.`;
  }

  // Respostas sobre exames
  if (lowerMessage.includes('hemoglobina')) {
    return `Hemoglobina é a proteína que transporta oxigênio no sangue.
Valores normais:
- Homens: 13.5-17.5 g/dL
- Mulheres: 12.0-15.5 g/dL

Hemoglobina baixa pode indicar anemia.
Hemoglobina alta pode indicar desidratação ou policitemia.
Consulte um médico para interpretação completa.`;
  }

  if (lowerMessage.includes('glicemia') || lowerMessage.includes('glicose')) {
    return `Glicemia é o nível de açúcar no sangue.
Valores normais em jejum: 70-99 mg/dL

Classificação:
- Normal: < 100 mg/dL
- Pré-diabetes: 100-125 mg/dL
- Diabetes: ≥ 126 mg/dL

Manter glicemia controlada é importante para saúde cardiovascular.
Consulte um médico se tiver valores alterados.`;
  }

  if (lowerMessage.includes('colesterol')) {
    return `Colesterol é uma gordura essencial no corpo.
Valores desejáveis:
- Colesterol total: < 200 mg/dL
- LDL (colesterol ruim): < 130 mg/dL
- HDL (colesterol bom): > 40 mg/dL (homens), > 50 mg/dL (mulheres)

Colesterol alto aumenta risco de doença cardiovascular.
Dieta e exercício ajudam a controlar.
Consulte um médico para recomendações.`;
  }

  // Resposta genérica
  return `Sou um assistente farmacêutico. Posso ajudar com informações sobre:
- Medicamentos comuns
- Valores de referência de exames
- Interações medicamentosas
- Dúvidas gerais de saúde

⚠️ IMPORTANTE: Esta informação é apenas educacional e não substitui orientação médica profissional.

Qual é sua pergunta?`;
}

/**
 * Gera ID único para mensagem
 */
export function generateMessageId(): string {
  return `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * Cria nova mensagem de chat
 */
export function createChatMessage(
  role: 'user' | 'assistant',
  content: string
): ChatMessage {
  return {
    id: generateMessageId(),
    role,
    content,
    timestamp: Date.now(),
  };
}
