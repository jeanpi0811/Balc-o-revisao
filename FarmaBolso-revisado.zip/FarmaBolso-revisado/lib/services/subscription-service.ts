/**
 * Serviço de Gerenciamento de Acesso Premium (Pagamento Único)
 */

export type PlanType = 'free' | 'premium';

export interface UserSubscription {
  userId: number;
  planType: PlanType;
  status: 'active' | 'inactive' | 'expired';
  startDate: Date;
  endDate?: Date;
  pagseguroSubscriptionId?: string;
}

export interface DailyUsageStats {
  userId: number;
  date: string;
  totalCount: number;
}

/**
 * Configuração do Acesso Premium
 */
export const PREMIUM_ACCESS = {
  name: 'Acesso Premium',
  price: 9.90,
  durationDays: 30,
  features: [
    'Consultas ilimitadas por 30 dias',
    'Acesso completo a bulas',
    'Consulta de exames avançada',
    'Chat com IA sem limite',
    'Sem publicidade',
  ],
};

/**
 * Verifica se o usuário tem acesso ativo
 */
export function hasActiveAccess(subscription: UserSubscription): boolean {
  if (subscription.status !== 'active') return false;
  if (subscription.endDate && new Date(subscription.endDate) < new Date()) return false;
  return true;
}

/**
 * Formata o preço para exibição
 */
export function formatPrice(price: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(price);
}

/**
 * Gera URL de pagamento único PagSeguro (Checkout v2)
 */
export function generatePagSeguroPaymentUrl(
  userId: number,
  userEmail: string
): string {
  const baseUrl = 'https://checkout.pagseguro.com/checkout/v2/checkout.html';
  const params = new URLSearchParams({
    email: 'jean_pharma08@ymail.com',
    token: 'b899212b-d3de-41b6-93f7-cabc4f85f20dcfd9e16c466cadf4cdc646987c464db44a9d-1063-4457-adaa-91aad37263ce',
    reference: `access_${userId}_${Date.now()}`,
    senderEmail: userEmail,
    itemId1: 'premium_30d',
    itemDescription1: 'Acesso Premium Farma Bolso - 30 Dias',
    itemAmount1: '9.90',
    itemQuantity1: '1',
  });

  return `${baseUrl}?${params.toString()}`;
}
