/**
 * Serviço de IA Farmacêutica Melhorado
 * Usa Groq API (gratuita e rápida) como padrão com fallback para respostas locais
 * Groq: https://console.groq.com/keys (obtenha chave gratuita)
 */

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

const SYSTEM_PROMPT = `Você é um assistente farmacêutico especializado e educacional. 
Sua função é fornecer informações básicas sobre medicamentos, exames laboratoriais e saúde.

IMPORTANTE:
- Respostas devem ser informativas e educacionais
- Sempre recomende consulta médica para diagnósticos ou prescrições
- Não forneça recomendações de medicamentos específicos
- Mantenha respostas concisas e claras (máximo 300 palavras)
- Use linguagem acessível
- Cite valores de referência quando relevante

Aviso padrão: "⚠️ Esta informação é apenas educacional e não substitui orientação médica profissional. Consulte um médico para diagnóstico e tratamento."`;

/**
 * Envia mensagem para IA usando Groq API (gratuita)
 */
export async function sendChatMessage(
  message: string,
  conversationHistory: ChatMessage[] = []
): Promise<string> {
  try {
    // Tenta usar Groq API (gratuita)
    const groqApiKey = process.env.GROQ_API_KEY || '';
    
    if (groqApiKey) {
      try {
        const messages = [
          ...conversationHistory.map((msg) => ({
            role: msg.role,
            content: msg.content,
          })),
          {
            role: 'user' as const,
            content: message,
          },
        ];

        const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${groqApiKey}`,
          },
          body: JSON.stringify({
            model: 'mixtral-8x7b-32768', // Modelo rápido e gratuito
            messages: [
              {
                role: 'system',
                content: SYSTEM_PROMPT,
              },
              ...messages,
            ],
            temperature: 0.7,
            max_tokens: 500,
          }),
        });

        if (response.ok) {
          const data = await response.json();
          return (
            data.choices?.[0]?.message?.content ||
            'Desculpe, não consegui processar sua pergunta.'
          );
        }
      } catch (error) {
        console.error('Error calling Groq API:', error);
      }
    }

    // Fallback para respostas locais
    return getLocalAIResponse(message);
  } catch (error) {
    console.error('Error in AI service:', error);
    return getLocalAIResponse(message);
  }
}

/**
 * Respostas locais de IA (sem API)
 * Útil para quando não há conexão ou API indisponível
 */
function getLocalAIResponse(message: string): string {
  const lowerMessage = message.toLowerCase();

  // ==================== MEDICAMENTOS ====================
  if (lowerMessage.includes('dipirona') || lowerMessage.includes('dipirona')) {
    return `**Dipirona (Metamizol)**

Classe: Analgésico e antitérmico

Indicações:
- Dor (leve a moderada)
- Febre

Dosagem típica:
- Adultos: 500mg a cada 6-8 horas
- Máximo: 2g por dia

Efeitos colaterais:
- Raro, mas pode causar reações alérgicas graves
- Agranulocitose (muito raro)

⚠️ Não combine com outros analgésicos. Consulte um médico.`;
  }

  if (lowerMessage.includes('ibuprofeno')) {
    return `**Ibuprofeno**

Classe: Anti-inflamatório não-esteroidal (AINE)

Indicações:
- Dor (leve a moderada)
- Inflamação
- Febre

Dosagem típica:
- Adultos: 200-400mg a cada 6-8 horas
- Máximo: 1.2g por dia

Efeitos colaterais:
- Desconforto gástrico
- Úlcera (uso prolongado)
- Problemas renais

⚠️ Não use se tiver úlcera ou problemas renais. Consulte um médico.`;
  }

  if (lowerMessage.includes('paracetamol') || lowerMessage.includes('acetaminofeno')) {
    return `**Paracetamol (Acetaminofeno)**

Classe: Analgésico e antitérmico

Indicações:
- Dor (leve a moderada)
- Febre

Dosagem típica:
- Adultos: 500-1000mg a cada 6 horas
- Máximo: 4g por dia

Efeitos colaterais:
- Geralmente bem tolerado
- Raro em doses recomendadas

⚠️ Evite em excesso - pode danificar o fígado. Consulte um médico.`;
  }

  if (lowerMessage.includes('antibiótico') || lowerMessage.includes('amoxicilina')) {
    return `**Antibióticos**

Os antibióticos são medicamentos que combatem infecções bacterianas.

Tipos comuns:
- Penicilinas (Amoxicilina, Ampicilina)
- Cefalosporinas
- Fluoroquinolonas
- Macrolídeos

Informações importantes:
- Sempre complete o tratamento conforme prescrito
- Não compartilhe com outras pessoas
- Alguns podem interagir com contraceptivos

⚠️ Só use conforme prescrição médica. Automedicação pode causar resistência bacteriana.`;
  }

  // ==================== EXAMES ====================
  if (lowerMessage.includes('hemoglobina')) {
    return `**Hemoglobina**

Proteína que transporta oxigênio no sangue.

Valores normais:
- Homens: 13.5-17.5 g/dL
- Mulheres: 12.0-15.5 g/dL

Interpretação:
- Baixa (Anemia): Fraqueza, fadiga, falta de ar
- Normal: Nível adequado de oxigênio
- Alta (Policitemia): Desidratação, hipóxia crônica

Causas de alteração:
- Baixa: Deficiência de ferro, B12, ácido fólico
- Alta: Desidratação, altitude, doença pulmonar

⚠️ Consulte um médico para interpretação completa.`;
  }

  if (lowerMessage.includes('glicemia') || lowerMessage.includes('glicose')) {
    return `**Glicemia (Glicose no Sangue)**

Nível de açúcar no sangue.

Valores normais em jejum:
- 70-99 mg/dL

Classificação:
- Normal: < 100 mg/dL
- Pré-diabetes: 100-125 mg/dL
- Diabetes: ≥ 126 mg/dL

Hemoglobina Glicada (HbA1c):
- Normal: < 5.7%
- Pré-diabetes: 5.7-6.4%
- Diabetes: ≥ 6.5%

Manter glicemia controlada é importante para:
- Saúde cardiovascular
- Função renal
- Visão

⚠️ Consulte um médico se tiver valores alterados.`;
  }

  if (lowerMessage.includes('colesterol')) {
    return `**Colesterol**

Gordura essencial no corpo, mas em excesso aumenta risco cardiovascular.

Valores desejáveis:
- Colesterol total: < 200 mg/dL
- LDL (colesterol ruim): < 130 mg/dL
- HDL (colesterol bom): > 40 mg/dL (homens), > 50 mg/dL (mulheres)
- Triglicerídeos: < 150 mg/dL

Fatores de risco:
- Dieta rica em gordura saturada
- Sedentarismo
- Obesidade
- Histórico familiar

Prevenção:
- Dieta saudável
- Exercício regular
- Manutenção de peso

⚠️ Colesterol alto aumenta risco de infarto e AVC.`;
  }

  if (lowerMessage.includes('creatinina') || lowerMessage.includes('função renal')) {
    return `**Creatinina e Função Renal**

Indicador de saúde dos rins.

Valores normais:
- Homens: 0.7-1.3 mg/dL
- Mulheres: 0.6-1.1 mg/dL

Taxa de Filtração Glomerular (TFG):
- Normal: ≥ 60 mL/min/1.73m²
- Estágio 3: 30-59 (insuficiência leve)
- Estágio 4: 15-29 (insuficiência moderada)
- Estágio 5: < 15 (insuficiência grave)

Sinais de alerta:
- Creatinina elevada
- Inchaço nas pernas/pés
- Fadiga
- Pressão alta

⚠️ Insuficiência renal é séria. Procure médico se tiver valores alterados.`;
  }

  if (lowerMessage.includes('tsh') || lowerMessage.includes('tireoide')) {
    return `**TSH e Função Tireoidiana**

TSH (Hormônio Estimulante da Tireoide) regula a tireoide.

Valores normais:
- TSH: 0.4-4.0 mIU/L
- T4 Livre: 0.8-1.8 ng/dL

Hipotireoidismo (TSH alto):
- Metabolismo lento
- Fadiga, ganho de peso
- Queda de cabelo
- Depressão

Hipertireoidismo (TSH baixo):
- Metabolismo acelerado
- Perda de peso, taquicardia
- Ansiedade, tremor
- Intolerância ao calor

Tratamento:
- Medicamentos (Levotiroxina, Propranolol)
- Monitoramento regular

⚠️ Disfunção tireoidiana é comum. Consulte um médico.`;
  }

  // ==================== SAÚDE GERAL ====================
  if (lowerMessage.includes('pressão') || lowerMessage.includes('hipertensão')) {
    return `**Pressão Arterial e Hipertensão**

Valores normais:
- Sistólica (máxima): < 120 mmHg
- Diastólica (mínima): < 80 mmHg

Classificação:
- Normal: < 120/80
- Elevada: 120-129 / < 80
- Estágio 1: 130-139 / 80-89
- Estágio 2: ≥ 140 / ≥ 90

Fatores de risco:
- Obesidade
- Sedentarismo
- Dieta rica em sal
- Estresse
- Histórico familiar

Prevenção:
- Exercício regular
- Dieta saudável (menos sal)
- Redução de peso
- Controle de estresse

⚠️ Pressão alta aumenta risco de infarto e AVC.`;
  }

  if (lowerMessage.includes('imc') || lowerMessage.includes('peso')) {
    return `**Índice de Massa Corporal (IMC)**

Fórmula: Peso (kg) / Altura² (m)

Classificação:
- Abaixo do peso: < 18.5
- Peso normal: 18.5-24.9
- Sobrepeso: 25-29.9
- Obesidade grau 1: 30-34.9
- Obesidade grau 2: 35-39.9
- Obesidade grau 3: ≥ 40

Riscos da obesidade:
- Diabetes
- Doença cardiovascular
- Pressão alta
- Apneia do sono

Dicas para manter peso saudável:
- Dieta balanceada
- Exercício regular (150 min/semana)
- Dormir bem
- Gerenciar estresse

⚠️ Consulte um nutricionista para plano personalizado.`;
  }

  // ==================== RESPOSTA GENÉRICA ====================
  return `Sou um assistente farmacêutico educacional. Posso ajudar com informações sobre:

📚 **Medicamentos comuns**
- Indicações, dosagem, efeitos colaterais
- Interações medicamentosas

🔬 **Exames laboratoriais**
- Valores de referência
- Interpretação de resultados
- O que significam alterações

💊 **Saúde geral**
- Dicas de prevenção
- Fatores de risco
- Quando procurar médico

⚠️ **IMPORTANTE**: Esta informação é apenas educacional e não substitui orientação médica profissional.

Qual é sua pergunta?`;
}

/**
 * Gera ID único para mensagem
 */
export function generateMessageId(): string {
  return `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * Cria nova mensagem de chat
 */
export function createChatMessage(
  role: 'user' | 'assistant',
  content: string
): ChatMessage {
  return {
    id: generateMessageId(),
    role,
    content,
    timestamp: Date.now(),
  };
}
