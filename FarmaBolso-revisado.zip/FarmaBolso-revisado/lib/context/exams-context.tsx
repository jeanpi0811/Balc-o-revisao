import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getExamStatus, LabReference } from '../data/lab-references';

export interface UserExam {
  id: string;
  referenceId: string; // ID do exame de referência
  value: number;
  date: string;
  notes?: string;
  gender: 'male' | 'female';
}

interface ExamsContextType {
  exams: UserExam[];
  addExam: (exam: Omit<UserExam, 'id'>) => Promise<void>;
  removeExam: (id: string) => Promise<void>;
  updateExam: (id: string, exam: Partial<UserExam>) => Promise<void>;
  getExamsByReference: (referenceId: string) => UserExam[];
  getLatestExam: (referenceId: string) => UserExam | undefined;
  isLoading: boolean;
}

const ExamsContext = createContext<ExamsContextType | undefined>(undefined);

const STORAGE_KEY = '@farma_bolso_exams';

export function ExamsProvider({ children }: { children: React.ReactNode }) {
  const [exams, setExams] = useState<UserExam[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Carrega exames do AsyncStorage ao inicializar
  useEffect(() => {
    loadExams();
  }, []);

  const loadExams = async () => {
    try {
      const stored = await AsyncStorage.getItem(STORAGE_KEY);
      if (stored) {
        setExams(JSON.parse(stored));
      }
    } catch (error) {
      console.error('Error loading exams:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const saveExams = async (newExams: UserExam[]) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(newExams));
      setExams(newExams);
    } catch (error) {
      console.error('Error saving exams:', error);
      throw error;
    }
  };

  const addExam = async (exam: Omit<UserExam, 'id'>) => {
    const newExam: UserExam = {
      ...exam,
      id: `exam_${Date.now()}`,
    };

    const updated = [...exams, newExam];
    await saveExams(updated);
  };

  const removeExam = async (id: string) => {
    const updated = exams.filter((exam) => exam.id !== id);
    await saveExams(updated);
  };

  const updateExam = async (id: string, updates: Partial<UserExam>) => {
    const updated = exams.map((exam) =>
      exam.id === id ? { ...exam, ...updates } : exam
    );
    await saveExams(updated);
  };

  const getExamsByReference = (referenceId: string): UserExam[] => {
    return exams.filter((exam) => exam.referenceId === referenceId);
  };

  const getLatestExam = (referenceId: string): UserExam | undefined => {
    const filtered = getExamsByReference(referenceId);
    if (filtered.length === 0) return undefined;

    return filtered.reduce((latest, current) => {
      const latestDate = new Date(latest.date).getTime();
      const currentDate = new Date(current.date).getTime();
      return currentDate > latestDate ? current : latest;
    });
  };

  return (
    <ExamsContext.Provider
      value={{
        exams,
        addExam,
        removeExam,
        updateExam,
        getExamsByReference,
        getLatestExam,
        isLoading,
      }}
    >
      {children}
    </ExamsContext.Provider>
  );
}

export function useExams() {
  const context = useContext(ExamsContext);
  if (!context) {
    throw new Error('useExams must be used within ExamsProvider');
  }
  return context;
}
