import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { checkInteractions, MedicationInteraction } from '../data/lab-references';

export interface UserMedication {
  id: string;
  name: string;
  dosage: string;
  frequency: string;
  startDate: string;
  notes?: string;
}

interface MedicationsContextType {
  medications: UserMedication[];
  addMedication: (medication: Omit<UserMedication, 'id'>) => Promise<void>;
  removeMedication: (id: string) => Promise<void>;
  updateMedication: (id: string, medication: Partial<UserMedication>) => Promise<void>;
  getInteractions: () => MedicationInteraction[];
  isLoading: boolean;
}

const MedicationsContext = createContext<MedicationsContextType | undefined>(undefined);

const STORAGE_KEY = '@farma_bolso_medications';

export function MedicationsProvider({ children }: { children: React.ReactNode }) {
  const [medications, setMedications] = useState<UserMedication[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Carrega medicamentos do AsyncStorage ao inicializar
  useEffect(() => {
    loadMedications();
  }, []);

  const loadMedications = async () => {
    try {
      const stored = await AsyncStorage.getItem(STORAGE_KEY);
      if (stored) {
        setMedications(JSON.parse(stored));
      }
    } catch (error) {
      console.error('Error loading medications:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const saveMedications = async (newMedications: UserMedication[]) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(newMedications));
      setMedications(newMedications);
    } catch (error) {
      console.error('Error saving medications:', error);
      throw error;
    }
  };

  const addMedication = async (medication: Omit<UserMedication, 'id'>) => {
    const newMedication: UserMedication = {
      ...medication,
      id: `med_${Date.now()}`,
    };

    const updated = [...medications, newMedication];
    await saveMedications(updated);
  };

  const removeMedication = async (id: string) => {
    const updated = medications.filter((med) => med.id !== id);
    await saveMedications(updated);
  };

  const updateMedication = async (id: string, updates: Partial<UserMedication>) => {
    const updated = medications.map((med) =>
      med.id === id ? { ...med, ...updates } : med
    );
    await saveMedications(updated);
  };

  const getInteractions = (): MedicationInteraction[] => {
    const medicationNames = medications.map((med) => med.name);
    return checkInteractions(medicationNames);
  };

  return (
    <MedicationsContext.Provider
      value={{
        medications,
        addMedication,
        removeMedication,
        updateMedication,
        getInteractions,
        isLoading,
      }}
    >
      {children}
    </MedicationsContext.Provider>
  );
}

export function useMedications() {
  const context = useContext(MedicationsContext);
  if (!context) {
    throw new Error('useMedications must be used within MedicationsProvider');
  }
  return context;
}
