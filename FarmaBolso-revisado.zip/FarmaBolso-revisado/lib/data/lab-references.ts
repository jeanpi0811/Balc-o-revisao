/**
 * Valores de referência para exames laboratoriais comuns
 * Fonte: Sociedades médicas brasileiras, PNCQ, SBPC, protocolos internacionais e literatura médica
 * Atualizado: 2024-2025
 */

export interface LabReference {
  id: string;
  name: string;
  category: 'hematology' | 'biochemistry' | 'lipids' | 'thyroid' | 'liver' | 'kidney' | 'urine' | 'immunology' | 'coagulation' | 'endocrine';
  unit: string;
  description: string;
  reference: {
    male: { min: number; max: number };
    female: { min: number; max: number };
  };
  interpretation: {
    low: string;
    normal: string;
    high: string;
  };
  clinicalSignificance?: string;
  notes?: string;
}

export const labReferences: LabReference[] = [
  // ==================== HEMATOLOGY ====================
  {
    id: 'hemoglobin',
    name: 'Hemoglobina',
    category: 'hematology',
    unit: 'g/dL',
    description: 'Proteína que transporta oxigênio no sangue',
    reference: {
      male: { min: 13.5, max: 17.5 },
      female: { min: 12.0, max: 15.5 },
    },
    interpretation: {
      low: 'Anemia - pode causar fraqueza, fadiga e falta de ar',
      normal: 'Nível normal de hemoglobina',
      high: 'Policitemia - aumento de glóbulos vermelhos, desidratação ou hipóxia crônica',
    },
    clinicalSignificance: 'Indicador essencial de anemia e capacidade de transporte de oxigênio',
  },
  {
    id: 'hematocrit',
    name: 'Hematócrito',
    category: 'hematology',
    unit: '%',
    description: 'Percentual de glóbulos vermelhos no sangue',
    reference: {
      male: { min: 40, max: 54 },
      female: { min: 36, max: 46 },
    },
    interpretation: {
      low: 'Anemia - redução de glóbulos vermelhos',
      normal: 'Nível normal de hematócrito',
      high: 'Desidratação, policitemia ou hipóxia crônica',
    },
    clinicalSignificance: 'Correlaciona com hemoglobina; importante para avaliar anemia',
  },
  {
    id: 'wbc',
    name: 'Leucócitos (Glóbulos Brancos)',
    category: 'hematology',
    unit: '×10³/μL',
    description: 'Células de defesa do corpo',
    reference: {
      male: { min: 4.5, max: 11.0 },
      female: { min: 4.5, max: 11.0 },
    },
    interpretation: {
      low: 'Leucopenia - imunodeficiência, risco de infecções, efeito de medicamentos',
      normal: 'Nível normal de defesa',
      high: 'Leucocitose - infecção, inflamação, estresse, leucemia',
    },
    clinicalSignificance: 'Indicador de infecção, inflamação e função imunológica',
  },
  {
    id: 'platelets',
    name: 'Plaquetas',
    category: 'hematology',
    unit: '×10³/μL',
    description: 'Células responsáveis pela coagulação',
    reference: {
      male: { min: 150, max: 400 },
      female: { min: 150, max: 400 },
    },
    interpretation: {
      low: 'Trombocitopenia - risco de sangramento, hematomas fáceis',
      normal: 'Coagulação normal',
      high: 'Trombocitose - risco de trombose, tromboembolismo',
    },
    clinicalSignificance: 'Essencial para avaliação de coagulação e risco hemorrágico',
  },
  {
    id: 'mch',
    name: 'MCH (Hemoglobina Corpuscular Média)',
    category: 'hematology',
    unit: 'pg',
    description: 'Quantidade média de hemoglobina por glóbulo vermelho',
    reference: {
      male: { min: 27, max: 33 },
      female: { min: 27, max: 33 },
    },
    interpretation: {
      low: 'Anemia hipocômica - deficiência de ferro, talassemia',
      normal: 'Nível normal',
      high: 'Anemia macrocítica - deficiência de B12, ácido fólico',
    },
  },
  {
    id: 'mchc',
    name: 'MCHC (Concentração de Hemoglobina Corpuscular Média)',
    category: 'hematology',
    unit: 'g/dL',
    description: 'Concentração média de hemoglobina nos glóbulos vermelhos',
    reference: {
      male: { min: 32, max: 36 },
      female: { min: 32, max: 36 },
    },
    interpretation: {
      low: 'Anemia hipocômica - deficiência de ferro',
      normal: 'Nível normal',
      high: 'Raro - pode indicar erro de laboratório',
    },
  },
  {
    id: 'rdw',
    name: 'RDW (Amplitude de Distribuição dos Glóbulos Vermelhos)',
    category: 'hematology',
    unit: '%',
    description: 'Variação no tamanho dos glóbulos vermelhos',
    reference: {
      male: { min: 11.5, max: 14.5 },
      female: { min: 11.5, max: 14.5 },
    },
    interpretation: {
      low: 'Raro',
      normal: 'Nível normal',
      high: 'Anisocitose - deficiência de ferro, B12, ácido fólico',
    },
  },

  // ==================== BIOCHEMISTRY ====================
  {
    id: 'glucose_fasting',
    name: 'Glicemia de Jejum',
    category: 'biochemistry',
    unit: 'mg/dL',
    description: 'Nível de açúcar no sangue após 8-12h de jejum',
    reference: {
      male: { min: 70, max: 99 },
      female: { min: 70, max: 99 },
    },
    interpretation: {
      low: 'Hipoglicemia - risco de desmaio, confusão mental, convulsões',
      normal: 'Glicemia normal',
      high: 'Pré-diabetes (100-125) ou Diabetes (≥126)',
    },
    clinicalSignificance: 'Essencial para diagnóstico de diabetes e controle glicêmico',
  },
  {
    id: 'glucose_random',
    name: 'Glicemia Aleatória',
    category: 'biochemistry',
    unit: 'mg/dL',
    description: 'Nível de açúcar no sangue sem jejum',
    reference: {
      male: { min: 70, max: 140 },
      female: { min: 70, max: 140 },
    },
    interpretation: {
      low: 'Hipoglicemia',
      normal: 'Nível normal',
      high: 'Possível diabetes ou intolerância à glicose',
    },
  },
  {
    id: 'hba1c',
    name: 'Hemoglobina Glicada (HbA1c)',
    category: 'biochemistry',
    unit: '%',
    description: 'Média de glicemia dos últimos 2-3 meses',
    reference: {
      male: { min: 0, max: 5.7 },
      female: { min: 0, max: 5.7 },
    },
    interpretation: {
      low: 'Hipoglicemia crônica',
      normal: 'Controle glicêmico normal (<5.7%)',
      high: 'Pré-diabetes (5.7-6.4%) ou Diabetes (≥6.5%)',
    },
    clinicalSignificance: 'Melhor indicador de controle glicêmico a longo prazo',
  },
  {
    id: 'creatinine',
    name: 'Creatinina',
    category: 'kidney',
    unit: 'mg/dL',
    description: 'Indicador de função renal',
    reference: {
      male: { min: 0.7, max: 1.3 },
      female: { min: 0.6, max: 1.1 },
    },
    interpretation: {
      low: 'Raro - pode indicar desnutrição, doença hepática',
      normal: 'Função renal normal',
      high: 'Insuficiência renal - procure médico urgentemente',
    },
    clinicalSignificance: 'Principal marcador de função renal',
  },
  {
    id: 'urea',
    name: 'Ureia',
    category: 'kidney',
    unit: 'mg/dL',
    description: 'Produto do metabolismo proteico',
    reference: {
      male: { min: 7, max: 20 },
      female: { min: 7, max: 20 },
    },
    interpretation: {
      low: 'Desnutrição, doença hepática, gravidez',
      normal: 'Nível normal',
      high: 'Insuficiência renal, desidratação, catabolismo aumentado',
    },
    clinicalSignificance: 'Complementa avaliação de função renal com creatinina',
  },
  {
    id: 'egfr',
    name: 'TFG (Taxa de Filtração Glomerular)',
    category: 'kidney',
    unit: 'mL/min/1.73m²',
    description: 'Estimativa de função renal',
    reference: {
      male: { min: 60, max: 999 },
      female: { min: 60, max: 999 },
    },
    interpretation: {
      low: 'Insuficiência renal - estágios 3-5',
      normal: 'Função renal normal (≥60)',
      high: 'Função renal normal',
    },
    clinicalSignificance: 'Melhor estimativa de função renal que creatinina isolada',
  },
  {
    id: 'sodium',
    name: 'Sódio',
    category: 'biochemistry',
    unit: 'mEq/L',
    description: 'Eletrólito essencial para equilíbrio hídrico',
    reference: {
      male: { min: 136, max: 145 },
      female: { min: 136, max: 145 },
    },
    interpretation: {
      low: 'Hiponatremia - confusão, convulsões, edema cerebral',
      normal: 'Nível normal',
      high: 'Hipernatremia - sede, confusão, desidratação',
    },
  },
  {
    id: 'potassium',
    name: 'Potássio',
    category: 'biochemistry',
    unit: 'mEq/L',
    description: 'Eletrólito essencial para função cardíaca',
    reference: {
      male: { min: 3.5, max: 5.0 },
      female: { min: 3.5, max: 5.0 },
    },
    interpretation: {
      low: 'Hipocalemia - fraqueza muscular, arritmias cardíacas',
      normal: 'Nível normal',
      high: 'Hipercalemia - arritmias cardíacas graves, parada cardíaca',
    },
    clinicalSignificance: 'Crítico para função cardíaca e neuromuscular',
  },
  {
    id: 'calcium',
    name: 'Cálcio Total',
    category: 'biochemistry',
    unit: 'mg/dL',
    description: 'Mineral essencial para ossos e funções celulares',
    reference: {
      male: { min: 8.5, max: 10.2 },
      female: { min: 8.5, max: 10.2 },
    },
    interpretation: {
      low: 'Hipocalcemia - tetania, convulsões, osteoporose',
      normal: 'Nível normal',
      high: 'Hipercalcemia - fraqueza, náusea, insuficiência renal',
    },
  },
  {
    id: 'phosphorus',
    name: 'Fósforo',
    category: 'biochemistry',
    unit: 'mg/dL',
    description: 'Mineral importante para ossos e metabolismo energético',
    reference: {
      male: { min: 2.5, max: 4.5 },
      female: { min: 2.5, max: 4.5 },
    },
    interpretation: {
      low: 'Hipofosfatemia - fraqueza, osteoporose',
      normal: 'Nível normal',
      high: 'Hiperfosfatemia - insuficiência renal, hiperparatireoidismo',
    },
  },
  {
    id: 'magnesium',
    name: 'Magnésio',
    category: 'biochemistry',
    unit: 'mg/dL',
    description: 'Cofator de mais de 300 enzimas',
    reference: {
      male: { min: 1.7, max: 2.2 },
      female: { min: 1.7, max: 2.2 },
    },
    interpretation: {
      low: 'Hipomagnesemia - arritmias, fraqueza, espasmos',
      normal: 'Nível normal',
      high: 'Hipermagnesemia - fraqueza, hipotensão',
    },
  },

  // ==================== LIPIDS ====================
  {
    id: 'cholesterol_total',
    name: 'Colesterol Total',
    category: 'lipids',
    unit: 'mg/dL',
    description: 'Colesterol total no sangue',
    reference: {
      male: { min: 0, max: 200 },
      female: { min: 0, max: 200 },
    },
    interpretation: {
      low: 'Raro - pode indicar desnutrição, doença hepática',
      normal: 'Desejável (<200)',
      high: 'Risco de doença cardiovascular',
    },
    clinicalSignificance: 'Fator de risco importante para doença cardiovascular',
  },
  {
    id: 'ldl',
    name: 'Colesterol LDL',
    category: 'lipids',
    unit: 'mg/dL',
    description: 'Colesterol ruim - transporta lipídios para artérias',
    reference: {
      male: { min: 0, max: 130 },
      female: { min: 0, max: 130 },
    },
    interpretation: {
      low: 'Muito baixo - raro',
      normal: 'Ótimo (<100) ou Desejável (100-129)',
      high: 'Aumentado (130-159) ou Alto (≥160)',
    },
    clinicalSignificance: 'Principal fator de risco para aterosclerose',
    notes: 'Metas podem ser mais rigorosas em pacientes com doença cardiovascular',
  },
  {
    id: 'hdl',
    name: 'Colesterol HDL',
    category: 'lipids',
    unit: 'mg/dL',
    description: 'Colesterol bom - remove lipídios das artérias',
    reference: {
      male: { min: 40, max: 300 },
      female: { min: 50, max: 300 },
    },
    interpretation: {
      low: 'Risco de doença cardiovascular (<40 homens, <50 mulheres)',
      normal: 'Protetor (>40 homens, >50 mulheres; ótimo >60)',
      high: 'Muito protetor',
    },
    clinicalSignificance: 'Fator protetor contra doença cardiovascular',
  },
  {
    id: 'triglycerides',
    name: 'Triglicerídeos',
    category: 'lipids',
    unit: 'mg/dL',
    description: 'Tipo de gordura no sangue',
    reference: {
      male: { min: 0, max: 150 },
      female: { min: 0, max: 150 },
    },
    interpretation: {
      low: 'Normal',
      normal: 'Desejável (<150)',
      high: 'Aumentado (150-199) ou Alto (≥200)',
    },
    clinicalSignificance: 'Fator de risco para doença cardiovascular',
  },
  {
    id: 'vldl',
    name: 'VLDL (Lipoproteína de Muito Baixa Densidade)',
    category: 'lipids',
    unit: 'mg/dL',
    description: 'Transporta triglicerídeos',
    reference: {
      male: { min: 0, max: 40 },
      female: { min: 0, max: 40 },
    },
    interpretation: {
      low: 'Normal',
      normal: 'Normal',
      high: 'Aumentado - risco cardiovascular',
    },
  },

  // ==================== THYROID ====================
  {
    id: 'tsh',
    name: 'TSH (Hormônio Estimulante da Tireoide)',
    category: 'thyroid',
    unit: 'mIU/L',
    description: 'Hormônio que regula a tireoide',
    reference: {
      male: { min: 0.4, max: 4.0 },
      female: { min: 0.4, max: 4.0 },
    },
    interpretation: {
      low: 'Hipertireoidismo - metabolismo acelerado, taquicardia',
      normal: 'Função tireoidiana normal',
      high: 'Hipotireoidismo - metabolismo lento, fadiga',
    },
    clinicalSignificance: 'Melhor teste de rastreamento de disfunção tireoidiana',
  },
  {
    id: 't4_free',
    name: 'T4 Livre',
    category: 'thyroid',
    unit: 'ng/dL',
    description: 'Hormônio tireoidiano ativo',
    reference: {
      male: { min: 0.8, max: 1.8 },
      female: { min: 0.8, max: 1.8 },
    },
    interpretation: {
      low: 'Hipotireoidismo - fadiga, ganho de peso',
      normal: 'Função tireoidiana normal',
      high: 'Hipertireoidismo - perda de peso, taquicardia',
    },
  },
  {
    id: 't3_free',
    name: 'T3 Livre',
    category: 'thyroid',
    unit: 'pg/mL',
    description: 'Forma mais ativa do hormônio tireoidiano',
    reference: {
      male: { min: 2.3, max: 4.2 },
      female: { min: 2.3, max: 4.2 },
    },
    interpretation: {
      low: 'Hipotireoidismo',
      normal: 'Função tireoidiana normal',
      high: 'Hipertireoidismo',
    },
  },
  {
    id: 'tpo_antibody',
    name: 'Anticorpo Anti-TPO',
    category: 'thyroid',
    unit: 'IU/mL',
    description: 'Anticorpo contra peroxidase tireoidiana',
    reference: {
      male: { min: 0, max: 35 },
      female: { min: 0, max: 35 },
    },
    interpretation: {
      low: 'Normal',
      normal: 'Normal',
      high: 'Tireoidite autoimune (Hashimoto)',
    },
  },

  // ==================== LIVER ====================
  {
    id: 'ast',
    name: 'AST (Aspartato Aminotransferase)',
    category: 'liver',
    unit: 'U/L',
    description: 'Enzima hepática',
    reference: {
      male: { min: 10, max: 40 },
      female: { min: 7, max: 35 },
    },
    interpretation: {
      low: 'Normal',
      normal: 'Função hepática normal',
      high: 'Possível lesão hepática, infarto do miocárdio, miopatia',
    },
    clinicalSignificance: 'Marcador de lesão hepática e muscular',
  },
  {
    id: 'alt',
    name: 'ALT (Alanina Aminotransferase)',
    category: 'liver',
    unit: 'U/L',
    description: 'Enzima hepática mais específica',
    reference: {
      male: { min: 7, max: 56 },
      female: { min: 7, max: 45 },
    },
    interpretation: {
      low: 'Normal',
      normal: 'Função hepática normal',
      high: 'Possível lesão hepática (mais específica que AST)',
    },
    clinicalSignificance: 'Mais específica para lesão hepática que AST',
  },
  {
    id: 'ggt',
    name: 'GGT (Gama-Glutamiltransferase)',
    category: 'liver',
    unit: 'U/L',
    description: 'Enzima hepática',
    reference: {
      male: { min: 0, max: 65 },
      female: { min: 0, max: 36 },
    },
    interpretation: {
      low: 'Normal',
      normal: 'Normal',
      high: 'Doença hepática, alcoolismo, colestase',
    },
  },
  {
    id: 'bilirubin_total',
    name: 'Bilirrubina Total',
    category: 'liver',
    unit: 'mg/dL',
    description: 'Produto da degradação da hemoglobina',
    reference: {
      male: { min: 0.1, max: 1.2 },
      female: { min: 0.1, max: 1.2 },
    },
    interpretation: {
      low: 'Normal',
      normal: 'Normal',
      high: 'Icterícia - doença hepática, hemólise, colestase',
    },
    clinicalSignificance: 'Indicador de função hepática e hemólise',
  },
  {
    id: 'bilirubin_direct',
    name: 'Bilirrubina Direta',
    category: 'liver',
    unit: 'mg/dL',
    description: 'Bilirrubina conjugada',
    reference: {
      male: { min: 0.0, max: 0.3 },
      female: { min: 0.0, max: 0.3 },
    },
    interpretation: {
      low: 'Normal',
      normal: 'Normal',
      high: 'Colestase ou doença hepática',
    },
  },
  {
    id: 'albumin',
    name: 'Albumina',
    category: 'liver',
    unit: 'g/dL',
    description: 'Proteína sintetizada pelo fígado',
    reference: {
      male: { min: 3.5, max: 5.0 },
      female: { min: 3.5, max: 5.0 },
    },
    interpretation: {
      low: 'Desnutrição, doença hepática crônica, síndrome nefrótica',
      normal: 'Função hepática normal',
      high: 'Desidratação',
    },
    clinicalSignificance: 'Indicador de síntese hepática e estado nutricional',
  },
  {
    id: 'protein_total',
    name: 'Proteína Total',
    category: 'liver',
    unit: 'g/dL',
    description: 'Proteínas totais no sangue',
    reference: {
      male: { min: 6.0, max: 8.3 },
      female: { min: 6.0, max: 8.3 },
    },
    interpretation: {
      low: 'Desnutrição, doença hepática, síndrome nefrótica',
      normal: 'Normal',
      high: 'Desidratação, mieloma múltiplo',
    },
  },

  // ==================== COAGULATION ====================
  {
    id: 'pt_inr',
    name: 'PT/INR (Tempo de Protrombina)',
    category: 'coagulation',
    unit: 'segundos / razão',
    description: 'Avalia coagulação extrínseca',
    reference: {
      male: { min: 11, max: 13.5 },
      female: { min: 11, max: 13.5 },
    },
    interpretation: {
      low: 'Raro - coagulação aumentada',
      normal: 'Coagulação normal',
      high: 'Risco de sangramento - deficiência de fatores, anticoagulantes',
    },
    clinicalSignificance: 'Essencial para monitorar terapia anticoagulante',
  },
  {
    id: 'aptt',
    name: 'APPT (Tempo de Tromboplastina Parcial Ativada)',
    category: 'coagulation',
    unit: 'segundos',
    description: 'Avalia coagulação intrínseca',
    reference: {
      male: { min: 25, max: 35 },
      female: { min: 25, max: 35 },
    },
    interpretation: {
      low: 'Raro - coagulação aumentada',
      normal: 'Coagulação normal',
      high: 'Risco de sangramento - deficiência de fatores, heparina',
    },
  },
];

/**
 * Medicamentos comuns e suas interações
 */
export interface MedicationInteraction {
  drug1: string;
  drug2: string;
  severity: 'low' | 'moderate' | 'high';
  description: string;
  recommendation: string;
}

export const medicationInteractions: MedicationInteraction[] = [
  {
    drug1: 'Dipirona',
    drug2: 'Ibuprofeno',
    severity: 'high',
    description: 'Ambos são anti-inflamatórios. Usar juntos aumenta risco de úlcera gástrica e problemas renais.',
    recommendation: 'Não combine. Escolha um dos dois. Consulte um médico.',
  },
  {
    drug1: 'Dipirona',
    drug2: 'Paracetamol',
    severity: 'high',
    description: 'Ambos são analgésicos. Usar juntos pode causar toxicidade hepática.',
    recommendation: 'Não combine. Escolha um dos dois.',
  },
  {
    drug1: 'Ibuprofeno',
    drug2: 'Ácido Acetilsalicílico',
    severity: 'high',
    description: 'Ambos são anti-inflamatórios. Aumenta risco de sangramento e úlcera.',
    recommendation: 'Não combine. Escolha um dos dois.',
  },
  {
    drug1: 'Metformina',
    drug2: 'Álcool',
    severity: 'moderate',
    description: 'Álcool pode aumentar risco de acidose lática com metformina.',
    recommendation: 'Evite consumo excessivo de álcool.',
  },
  {
    drug1: 'Warfarina',
    drug2: 'Ibuprofeno',
    severity: 'high',
    description: 'Ibuprofeno aumenta efeito anticoagulante da warfarina, risco de sangramento.',
    recommendation: 'Consulte médico antes de usar. Prefira paracetamol.',
  },
  {
    drug1: 'Levotiroxina',
    drug2: 'Cálcio',
    severity: 'moderate',
    description: 'Cálcio reduz absorção de levotiroxina.',
    recommendation: 'Tome levotiroxina com 4 horas de intervalo do cálcio.',
  },
  {
    drug1: 'Amoxicilina',
    drug2: 'Contraceptivo Oral',
    severity: 'moderate',
    description: 'Antibióticos podem reduzir eficácia de contraceptivos.',
    recommendation: 'Use método contraceptivo adicional durante o uso de antibiótico.',
  },
  {
    drug1: 'Atorvastatina',
    drug2: 'Eritromicina',
    severity: 'moderate',
    description: 'Aumenta risco de miopatia e rabdomiólise.',
    recommendation: 'Evite ou monitore CK. Considere estatina alternativa.',
  },
  {
    drug1: 'Lisinopril',
    drug2: 'Potássio',
    severity: 'high',
    description: 'Aumenta risco de hipercalemia.',
    recommendation: 'Monitore potássio. Evite suplementação sem orientação médica.',
  },
];

/**
 * Função auxiliar para obter status de um valor
 */
export function getExamStatus(
  value: number,
  reference: LabReference,
  gender: 'male' | 'female'
): 'normal' | 'low' | 'high' {
  const ref = reference.reference[gender];
  if (value < ref.min) return 'low';
  if (value > ref.max) return 'high';
  return 'normal';
}

/**
 * Função para verificar interações entre medicamentos
 */
export function checkInteractions(
  medications: string[]
): MedicationInteraction[] {
  const interactions: MedicationInteraction[] = [];

  for (let i = 0; i < medications.length; i++) {
    for (let j = i + 1; j < medications.length; j++) {
      const interaction = medicationInteractions.find(
        (inter) =>
          (inter.drug1.toLowerCase() === medications[i].toLowerCase() &&
            inter.drug2.toLowerCase() === medications[j].toLowerCase()) ||
          (inter.drug1.toLowerCase() === medications[j].toLowerCase() &&
            inter.drug2.toLowerCase() === medications[i].toLowerCase())
      );

      if (interaction) {
        interactions.push(interaction);
      }
    }
  }

  return interactions;
}
