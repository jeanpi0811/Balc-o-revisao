# Design - Farma Bolso

## Visão Geral

**Farma Bolso** é um app farmacêutico que coloca informações críticas de saúde no bolso do usuário. O design segue **Apple Human Interface Guidelines (HIG)** para parecer um app nativo iOS, com suporte total a Android.

**Orientação:** Portrait (9:16)  
**Interação:** One-handed usage (botões e elementos críticos no terço inferior)

---

## Paleta de Cores

| Elemento | Cor | Uso |
|----------|-----|-----|
| **Primary** | #0a7ea4 (Azul Farmacêutico) | Botões principais, destaque |
| **Background** | #ffffff (Light) / #151718 (Dark) | Fundo das telas |
| **Surface** | #f5f5f5 (Light) / #1e2022 (Dark) | Cards, superfícies elevadas |
| **Foreground** | #11181C (Light) / #ECEDEE (Dark) | Texto principal |
| **Muted** | #687076 (Light) / #9BA1A6 (Dark) | Texto secundário |
| **Success** | #22C55E | Status normal, valores OK |
| **Warning** | #F59E0B | Valores alerta, atenção |
| **Error** | #EF4444 | Valores críticos, interações perigosas |

---

## Telas Principais

### 1. **Bulas** (Tab 1)
**Funcionalidade:** Pesquisa e visualização de bulas de medicamentos

**Conteúdo:**
- Campo de busca (topo)
- Lista de medicamentos encontrados (ScrollView)
- Card por medicamento com:
  - Nome do medicamento
  - Princípio ativo
  - Fabricante
  - Botão "Ver Bula" (abre PDF)

**Fluxo:**
1. Usuário digita nome do medicamento
2. API retorna lista de resultados
3. Usuário toca em medicamento → abre tela de detalhes
4. Tela de detalhes mostra informações + botão para baixar/visualizar PDF

---

### 2. **Exames Laboratoriais** (Tab 2)
**Funcionalidade:** Consulta de valores de referência e análise de resultados

**Conteúdo:**
- Abas internas:
  - **Valores de Referência:** Lista de exames com intervalos normais
  - **Meus Exames:** Exames salvos pelo usuário
  - **Câmera:** Capturar foto do exame

**Fluxo - Valores de Referência:**
1. Usuário busca exame (ex: "Hemoglobina")
2. App mostra intervalo normal para homens/mulheres
3. Usuário pode adicionar seu valor para comparação

**Fluxo - Meus Exames:**
1. Usuário toca "Adicionar Exame"
2. Escolhe entre:
   - Inserir manualmente (nome + valor)
   - Capturar foto do exame
3. App analisa e mostra:
   - Valor inserido vs. intervalo normal
   - Status (Verde = OK, Amarelo = Alerta, Vermelho = Crítico)
   - Recomendação: "Procure um médico"

---

### 3. **Meus Medicamentos** (Tab 3)
**Funcionalidade:** Gerenciar medicamentos e verificar interações

**Conteúdo:**
- Lista de medicamentos adicionados
- Card por medicamento com:
  - Nome
  - Dosagem
  - Frequência
  - Botão "Remover"
- Botão flutuante "+" para adicionar novo medicamento
- Seção "Alertas de Interação" (se houver)

**Fluxo:**
1. Usuário toca "+"
2. Busca medicamento por nome
3. Seleciona medicamento
4. Insere dosagem e frequência
5. App verifica interações com medicamentos já adicionados
6. Se houver interação:
   - Mostra alerta em vermelho
   - Descreve o risco resumidamente
   - Recomenda consulta médica

---

### 4. **IA Farmacêutica** (Tab 4)
**Funcionalidade:** Chat com IA para dúvidas farmacêuticas básicas

**Conteúdo:**
- Chat interface
- Histórico de mensagens
- Campo de entrada com botão enviar
- Indicador "IA está digitando..."

**Fluxo:**
1. Usuário digita pergunta (ex: "O que é dipirona?")
2. App envia para API de IA (DeepSeek/OpenAI)
3. IA responde com informação básica
4. Mensagem aparece no chat

**Limitações:**
- Respostas apenas informativas
- Aviso: "Não substitui consulta médica"

---

### 5. **Configurações** (Tab 5)
**Funcionalidade:** Perfil, privacidade e informações legais

**Subseções:**
- **Perfil:** Nome, email, data de nascimento (opcional)
- **Notificações:** Toggle para lembretes de medicamentos
- **LGPD:** Política de privacidade, direitos do usuário
- **Sobre:** Versão do app, créditos
- **Suporte:** Email de contato
- **Sair:** Logout (se houver auth)

---

## Fluxos Principais

### Fluxo 1: Verificar Interação Medicamentosa
```
Usuário abre "Meus Medicamentos"
  → Toca "+"
  → Busca "Dipirona"
  → Seleciona
  → Insere dosagem "500mg"
  → Insere frequência "8/8h"
  → App verifica interações com outros medicamentos
  → Se houver: mostra alerta em vermelho
  → Usuário confirma ou cancela
```

### Fluxo 2: Analisar Exame
```
Usuário abre "Exames"
  → Toca "Câmera"
  → Captura foto do exame
  → App processa imagem (OCR)
  → Extrai valores
  → Compara com intervalos normais
  → Mostra resultado (Verde/Amarelo/Vermelho)
```

### Fluxo 3: Buscar Bula
```
Usuário abre "Bulas"
  → Digita "Dipirona"
  → App busca via API ANVISA
  → Lista resultados
  → Usuário toca resultado
  → Abre tela de detalhes
  → Toca "Ver Bula"
  → PDF abre em visualizador
```

---

## Componentes Reutilizáveis

| Componente | Uso |
|------------|-----|
| **MedicineCard** | Exibir medicamento em lista |
| **ExamResultCard** | Mostrar resultado de exame com status |
| **InteractionAlert** | Aviso de interação medicamentosa |
| **ChatBubble** | Mensagem de chat (usuário/IA) |
| **TabBar** | Navegação inferior com 5 abas |
| **SearchBar** | Campo de busca com ícone |

---

## Considerações de UX

1. **Segurança:** Dados sensíveis (medicamentos, exames) armazenados localmente
2. **Acessibilidade:** Contraste alto, tamanho de fonte configurável
3. **Performance:** Listas usam FlatList, não ScrollView
4. **Feedback:** Botões mostram estado pressed, loading spinners em requisições
5. **Offline:** App funciona offline para dados já carregados
