# Farma Bolso - TODO

## Estrutura Base
- [x] Configurar tema de cores (azul farmacêutico)
- [x] Integrar ícone do app fornecido pelo usuário
- [x] Configurar app.config.ts com nome e slug
- [x] Criar estrutura de pastas para dados e serviços

## Aba 1: Bulas
- [x] Criar tela de Bulas com SearchBar
- [x] Integrar API bulario-api (ANVISA)
- [x] Implementar busca de medicamentos
- [x] Exibir lista de resultados em FlatList
- [ ] Criar tela de detalhes do medicamento
- [ ] Implementar visualizador de PDF
- [x] Adicionar cache local de bulas

## Aba 2: Exames Laboratoriais
- [x] Criar tela de Exames com abas internas
- [x] Implementar aba "Valores de Referência"
- [x] Criar banco de dados de exames (hemograma, glicemia, etc.)
- [x] Implementar aba "Meus Exames"
- [x] Criar formulário para adicionar exame manualmente
- [ ] Implementar aba "Câmera"
- [ ] Integrar camera (expo-camera) para capturar exames
- [ ] Implementar OCR básico para extração de valores
- [x] Criar lógica de comparação com valores de referência
- [x] Exibir status (Verde/Amarelo/Vermelho)
- [x] Salvar exames localmente (AsyncStorage)

## Aba 3: Meus Medicamentos
- [x] Criar tela de Meus Medicamentos
- [x] Implementar lista de medicamentos adicionados
- [x] Criar formulário para adicionar medicamento
- [ ] Integrar busca de medicamentos (API ANVISA)
- [x] Implementar banco de dados de interações medicamentosas
- [x] Criar lógica de verificação de interações
- [x] Exibir alertas de interação em vermelho
- [x] Implementar remoção de medicamentos
- [x] Salvar medicamentos localmente (AsyncStorage)

## Aba 4: IA Farmacêutica
- [x] Criar tela de Chat
- [x] Implementar interface de chat (ChatBubbles)
- [x] Integrar API de IA (DeepSeek/OpenAI)
- [x] Implementar envio de mensagens
- [x] Exibir respostas da IA
- [x] Adicionar indicador "IA está digitando..."
- [x] Implementar histórico de chat
- [x] Adicionar aviso: "Não substitui consulta médica"

## Aba 5: Configurações
- [x] Criar tela de Configurações
- [x] Implementar seção de Perfil (nome, email, data de nascimento)
- [x] Implementar toggle de Notificações
- [x] Criar página LGPD com política de privacidade
- [x] Criar página de Privacidade
- [x] Criar página "Sobre" com versão do app
- [ ] Implementar seção de Suporte (email)
- [ ] Adicionar opção de Sair (se houver auth)

## Componentes Reutilizáveis
- [ ] Criar componente MedicineCard
- [ ] Criar componente ExamResultCard
- [ ] Criar componente InteractionAlert
- [ ] Criar componente ChatBubble
- [ ] Criar componente SearchBar customizado
- [ ] Criar componente TabBar com 5 abas

## Dados e Serviços
- [ ] Criar serviço de API para Bulas
- [ ] Criar serviço de API para Exames
- [ ] Criar serviço de API para Interações Medicamentosas
- [ ] Criar serviço de API para IA
- [ ] Criar contexto para gerenciar medicamentos
- [ ] Criar contexto para gerenciar exames
- [ ] Implementar AsyncStorage para persistência local

## Testes e Polimento
- [ ] Testar fluxo de busca de bulas
- [ ] Testar adição de exames
- [ ] Testar verificação de interações
- [ ] Testar chat com IA
- [ ] Testar dark mode
- [ ] Testar responsividade em diferentes tamanhos
- [ ] Verificar performance de listas
- [ ] Testar offline (dados em cache)

## Branding e Publicação
- [x] Gerar logo customizado do app
- [x] Atualizar app.config.ts com logo URL
- [x] Criar splash screen
- [ ] Preparar para compilação (APK/IPA)
- [ ] Criar ZIP com código-fonte
- [ ] Criar página web de desenvolvimento
