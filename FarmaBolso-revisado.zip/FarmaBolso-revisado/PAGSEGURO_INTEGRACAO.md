# 💳 Guia de Integração PagSeguro

## 📋 Visão Geral

Este guia explica como integrar o PagSeguro para processar pagamentos dos planos de assinatura do Farma Bolso.

---

## 🔧 Pré-requisitos

1. **Conta PagSeguro** - Criar em [pagseguro.com.br](https://pagseguro.com.br)
2. **Chaves de API** - Gerar no painel do PagSeguro
3. **Node.js** - Versão 18+
4. **npm/pnpm** - Gerenciador de pacotes

---

## 🚀 Passo 1: Configurar Conta PagSeguro

### 1.1 Criar Conta
- Acesse [pagseguro.com.br](https://pagseguro.com.br)
- Clique em "Criar Conta"
- Preencha dados pessoais/empresariais
- Confirme email

### 1.2 Gerar Chaves de API
1. Faça login no painel
2. Vá para **Configurações** → **Integrações** → **Chaves de Acesso**
3. Gere chave de produção e teste
4. Copie:
   - **Token** (autenticação básica)
   - **Chave Pública** (para frontend)
   - **Chave Privada** (para backend)

### 1.3 Configurar Webhooks
1. Vá para **Configurações** → **Webhooks**
2. Adicione URL de notificação:
   ```
   https://seu-dominio.com/api/webhooks/pagseguro
   ```
3. Selecione eventos:
   - Pagamento aprovado
   - Pagamento recusado
   - Assinatura criada
   - Assinatura cancelada

---

## 🔐 Passo 2: Configurar Variáveis de Ambiente

Crie/atualize o arquivo `.env`:

```env
# PagSeguro - Credenciais
PAGSEGURO_API_KEY=seu_token_pagseguro
PAGSEGURO_PUBLIC_KEY=sua_chave_publica
PAGSEGURO_PRIVATE_KEY=sua_chave_privada

# PagSeguro - URLs
PAGSEGURO_API_URL=https://api.pagseguro.com
PAGSEGURO_CHECKOUT_URL=https://checkout.pagseguro.com

# Webhook
WEBHOOK_SECRET=seu_secret_para_validacao_webhook
```

---

## 📦 Passo 3: Instalar Dependências

```bash
pnpm add axios pagseguro-sdk
# ou
npm install axios pagseguro-sdk
```

---

## 💻 Passo 4: Implementar Backend

### 4.1 Criar Serviço PagSeguro

Arquivo: `server/services/pagseguro.ts`

```typescript
import axios from 'axios';

const PAGSEGURO_API = axios.create({
  baseURL: process.env.PAGSEGURO_API_URL,
  headers: {
    'Authorization': `Bearer ${process.env.PAGSEGURO_API_KEY}`,
    'Content-Type': 'application/json',
  },
});

export interface CreateSubscriptionPayload {
  planId: string;
  customerEmail: string;
  customerName: string;
  customerPhone: string;
  cardToken: string; // Token gerado no frontend
}

/**
 * Criar assinatura no PagSeguro
 */
export async function createSubscription(payload: CreateSubscriptionPayload) {
  try {
    const response = await PAGSEGURO_API.post('/subscriptions', {
      plan: {
        id: payload.planId,
      },
      customer: {
        name: payload.customerName,
        email: payload.customerEmail,
        phone: {
          country: '55',
          area: payload.customerPhone.substring(0, 2),
          number: payload.customerPhone.substring(2),
        },
      },
      paymentMethod: {
        type: 'CREDIT_CARD',
        creditCard: {
          token: payload.cardToken,
        },
      },
    });

    return response.data;
  } catch (error) {
    console.error('Error creating subscription:', error);
    throw error;
  }
}

/**
 * Obter detalhes da assinatura
 */
export async function getSubscription(subscriptionId: string) {
  try {
    const response = await PAGSEGURO_API.get(`/subscriptions/${subscriptionId}`);
    return response.data;
  } catch (error) {
    console.error('Error fetching subscription:', error);
    throw error;
  }
}

/**
 * Cancelar assinatura
 */
export async function cancelSubscription(subscriptionId: string) {
  try {
    const response = await PAGSEGURO_API.put(
      `/subscriptions/${subscriptionId}`,
      { status: 'CANCELLED' }
    );
    return response.data;
  } catch (error) {
    console.error('Error cancelling subscription:', error);
    throw error;
  }
}

/**
 * Validar webhook
 */
export function validateWebhook(signature: string, body: string): boolean {
  const crypto = require('crypto');
  const hash = crypto
    .createHmac('sha256', process.env.WEBHOOK_SECRET || '')
    .update(body)
    .digest('hex');
  
  return hash === signature;
}
```

### 4.2 Criar Router tRPC

Arquivo: `server/routers/subscription.ts`

```typescript
import { createTRPCRouter, protectedProcedure } from '@/server/_core/trpc';
import { z } from 'zod';
import * as pagseguroService from '@/server/services/pagseguro';
import { db } from '@/server/db';
import { subscriptions } from '@/drizzle/schema';

export const subscriptionRouter = createTRPCRouter({
  /**
   * Criar checkout para assinatura
   */
  createCheckout: protectedProcedure
    .input(
      z.object({
        planId: z.enum(['monthly', 'quarterly', 'semiannual', 'annual']),
        cardToken: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        // Mapear plano local para ID PagSeguro
        const planMap: Record<string, string> = {
          monthly: 'PLAN_MONTHLY',
          quarterly: 'PLAN_QUARTERLY',
          semiannual: 'PLAN_SEMIANNUAL',
          annual: 'PLAN_ANNUAL',
        };

        // Criar assinatura no PagSeguro
        const subscription = await pagseguroService.createSubscription({
          planId: planMap[input.planId],
          customerEmail: ctx.user.email || '',
          customerName: ctx.user.name || 'Usuário',
          customerPhone: '11999999999', // Obter do perfil do usuário
          cardToken: input.cardToken,
        });

        // Salvar no banco de dados
        const result = await db.subscriptions.create({
          userId: ctx.user.id,
          planType: input.planId,
          pagseguroSubscriptionId: subscription.id,
          status: 'active',
          startDate: new Date(),
          endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 dias
        });

        return {
          success: true,
          subscriptionId: result.id,
          pagseguroId: subscription.id,
        };
      } catch (error) {
        console.error('Error creating checkout:', error);
        throw new Error('Falha ao processar pagamento');
      }
    }),

  /**
   * Obter detalhes da assinatura atual
   */
  getCurrentSubscription: protectedProcedure.query(async ({ ctx }) => {
    try {
      const subscription = await db.subscriptions.findFirst({
        where: { userId: ctx.user.id },
        orderBy: { createdAt: 'desc' },
      });

      if (!subscription) {
        return null;
      }

      // Sincronizar com PagSeguro
      if (subscription.pagseguroSubscriptionId) {
        const pagseguroData = await pagseguroService.getSubscription(
          subscription.pagseguroSubscriptionId
        );

        // Atualizar status se mudou
        if (pagseguroData.status !== subscription.status) {
          await db.subscriptions.update({
            where: { id: subscription.id },
            data: { status: pagseguroData.status.toLowerCase() },
          });
        }
      }

      return subscription;
    } catch (error) {
      console.error('Error fetching subscription:', error);
      throw error;
    }
  }),

  /**
   * Cancelar assinatura
   */
  cancelSubscription: protectedProcedure.mutation(async ({ ctx }) => {
    try {
      const subscription = await db.subscriptions.findFirst({
        where: { userId: ctx.user.id, status: 'active' },
      });

      if (!subscription || !subscription.pagseguroSubscriptionId) {
        throw new Error('Nenhuma assinatura ativa encontrada');
      }

      // Cancelar no PagSeguro
      await pagseguroService.cancelSubscription(
        subscription.pagseguroSubscriptionId
      );

      // Atualizar no banco
      await db.subscriptions.update({
        where: { id: subscription.id },
        data: { status: 'cancelled' },
      });

      return { success: true };
    } catch (error) {
      console.error('Error cancelling subscription:', error);
      throw error;
    }
  }),
});
```

### 4.3 Criar Webhook Handler

Arquivo: `server/_core/webhooks.ts`

```typescript
import { Router } from 'express';
import * as pagseguroService from '@/server/services/pagseguro';
import { db } from '@/server/db';

export const webhookRouter = Router();

webhookRouter.post('/pagseguro', async (req, res) => {
  try {
    // Validar assinatura
    const signature = req.headers['x-pagseguro-signature'] as string;
    if (!pagseguroService.validateWebhook(signature, JSON.stringify(req.body))) {
      return res.status(401).json({ error: 'Invalid signature' });
    }

    const event = req.body;

    switch (event.type) {
      case 'subscription.created':
        console.log('Assinatura criada:', event.subscription.id);
        break;

      case 'subscription.updated':
        // Atualizar status no banco
        await db.subscriptions.updateMany({
          where: { pagseguroSubscriptionId: event.subscription.id },
          data: { status: event.subscription.status.toLowerCase() },
        });
        break;

      case 'subscription.canceled':
        // Cancelar assinatura
        await db.subscriptions.updateMany({
          where: { pagseguroSubscriptionId: event.subscription.id },
          data: { status: 'cancelled' },
        });
        break;

      case 'charge.completed':
        // Pagamento aprovado
        console.log('Pagamento aprovado:', event.charge.id);
        
        // Registrar no histórico
        await db.paymentHistory.create({
          userId: event.subscription.userId,
          subscriptionId: event.subscription.id,
          amount: parseFloat(event.charge.amount),
          pagseguroTransactionId: event.charge.id,
          status: 'completed',
        });
        break;

      case 'charge.failed':
        // Pagamento recusado
        console.log('Pagamento recusado:', event.charge.id);
        
        await db.paymentHistory.create({
          userId: event.subscription.userId,
          amount: parseFloat(event.charge.amount),
          pagseguroTransactionId: event.charge.id,
          status: 'failed',
        });
        break;
    }

    res.json({ success: true });
  } catch (error) {
    console.error('Webhook error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});
```

### 4.4 Registrar Webhook no Express

Arquivo: `server/_core/index.ts`

```typescript
import { webhookRouter } from './webhooks';

app.use('/api/webhooks', webhookRouter);
```

---

## 🎨 Passo 5: Implementar Frontend

### 5.1 Instalar PagSeguro SDK

```bash
pnpm add @pagseguro/checkout-sdk
```

### 5.2 Criar Componente de Checkout

Arquivo: `components/pagseguro-checkout.tsx`

```typescript
import { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, Alert } from 'react-native';
import { trpc } from '@/lib/trpc';

interface PagSeguroCheckoutProps {
  planId: string;
  onSuccess?: () => void;
  onError?: (error: Error) => void;
}

export function PagSeguroCheckout({
  planId,
  onSuccess,
  onError,
}: PagSeguroCheckoutProps) {
  const [loading, setLoading] = useState(false);
  const createCheckout = trpc.subscription.createCheckout.useMutation();

  const handlePayment = async () => {
    setLoading(true);
    try {
      // Em produção, usar biblioteca de cartão do PagSeguro
      // para obter token seguro
      const cardToken = 'token_do_cartao'; // Obter do componente de cartão

      const result = await createCheckout.mutateAsync({
        planId: planId as any,
        cardToken,
      });

      Alert.alert('Sucesso', 'Assinatura ativada com sucesso!');
      onSuccess?.();
    } catch (error) {
      Alert.alert('Erro', 'Falha ao processar pagamento');
      onError?.(error as Error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View>
      <TouchableOpacity
        onPress={handlePayment}
        disabled={loading}
        style={{
          backgroundColor: loading ? '#ccc' : '#007AFF',
          padding: 12,
          borderRadius: 8,
        }}
      >
        <Text style={{ color: '#fff', fontWeight: '600', textAlign: 'center' }}>
          {loading ? 'Processando...' : 'Pagar com PagSeguro'}
        </Text>
      </TouchableOpacity>
    </View>
  );
}
```

---

## 🧪 Passo 6: Testar Integração

### 6.1 Modo Teste
Use as credenciais de teste do PagSeguro:

```env
PAGSEGURO_API_KEY=test_token_pagseguro
```

### 6.2 Cartões de Teste
- **Visa:** 4111111111111111
- **Mastercard:** 5555555555554444
- **Elo:** 6362970000457013

### 6.3 Testar Webhook
Use ferramentas como Postman ou curl:

```bash
curl -X POST http://localhost:3000/api/webhooks/pagseguro \
  -H "Content-Type: application/json" \
  -H "X-PagSeguro-Signature: seu_hash" \
  -d '{
    "type": "subscription.created",
    "subscription": {
      "id": "SUB_123456",
      "status": "ACTIVE"
    }
  }'
```

---

## 📊 Monitorar Pagamentos

### Visualizar Transações
1. Painel PagSeguro → **Transações**
2. Filtrar por data e status
3. Exportar relatório

### Consultar via API
```typescript
// Obter histórico de pagamentos
const payments = await db.paymentHistory.findMany({
  where: { userId: ctx.user.id },
  orderBy: { createdAt: 'desc' },
});
```

---

## 🔒 Segurança

### Boas Práticas
1. **Nunca exponha chaves privadas** no frontend
2. **Use HTTPS** em produção
3. **Valide webhooks** com assinatura
4. **Criptografe dados sensíveis** no banco
5. **Implemente rate limiting** em endpoints de pagamento

### PCI Compliance
- Não armazene dados de cartão
- Use tokenização do PagSeguro
- Implemente 3D Secure

---

## 🆘 Troubleshooting

### Erro: "Invalid API Key"
- Verifique se a chave está correta no `.env`
- Confirme se está usando a chave de produção/teste correto

### Erro: "Webhook signature invalid"
- Verifique se o `WEBHOOK_SECRET` está correto
- Confirme se está usando o mesmo secret no PagSeguro

### Erro: "Subscription not found"
- Verifique se o ID da assinatura está correto
- Confirme se a assinatura foi criada com sucesso

---

## 📚 Referências

- [Documentação PagSeguro](https://developers.pagseguro.uol.com.br)
- [API de Assinaturas](https://developers.pagseguro.uol.com.br/reference/criar-assinatura)
- [Webhooks](https://developers.pagseguro.uol.com.br/reference/webhooks)

---

**Desenvolvido com ❤️ para melhorar o acesso à informação farmacêutica de qualidade.**
