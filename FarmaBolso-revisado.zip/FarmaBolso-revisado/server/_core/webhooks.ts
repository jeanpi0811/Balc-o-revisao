import { Router, Request, Response } from 'express';
import * as pagseguroService from '../services/pagseguro';
import { db } from '../db';
import { subscriptions } from '../../drizzle/schema';
import { eq } from 'drizzle-orm';

export const webhookRouter = Router();

/**
 * Webhook para eventos do PagSeguro/PagBank
 */
webhookRouter.post('/pagseguro', async (req: Request, res: Response) => {
  try {
    // Validar assinatura do webhook
    const signature = req.headers['x-pagseguro-signature'] as string;
    const body = JSON.stringify(req.body);

    if (!pagseguroService.validateWebhook(signature, body)) {
      console.warn('[Webhook] Assinatura inválida recebida');
      return res.status(401).json({ error: 'Invalid signature' });
    }

    const event = req.body;
    console.log('[Webhook] Evento recebido:', event.type);

    switch (event.type) {
      case 'order.paid':
      case 'charge.completed':
        // Pagamento aprovado
        console.log('[Webhook] Pagamento aprovado:', event.id);
        
        // Atualizar status da subscrição se existir
        if (event.reference_id) {
          const database = await db.select();
          if (database) {
            // Aqui você pode atualizar o status do pagamento no banco
            console.log('[Webhook] Atualizando referência:', event.reference_id);
          }
        }
        break;

      case 'order.denied':
      case 'charge.failed':
        // Pagamento recusado
        console.log('[Webhook] Pagamento recusado:', event.id);
        break;

      case 'subscription.created':
        console.log('[Webhook] Assinatura criada:', event.subscription?.id);
        break;

      case 'subscription.updated':
        // Atualizar status da assinatura
        if (event.subscription?.id) {
          console.log('[Webhook] Assinatura atualizada:', event.subscription.id);
        }
        break;

      case 'subscription.canceled':
        // Cancelar assinatura
        if (event.subscription?.id) {
          console.log('[Webhook] Assinatura cancelada:', event.subscription.id);
        }
        break;

      default:
        console.log('[Webhook] Tipo de evento não tratado:', event.type);
    }

    // Responder com sucesso
    res.json({ success: true });
  } catch (error) {
    console.error('[Webhook] Erro ao processar webhook:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});
