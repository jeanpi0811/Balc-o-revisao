import axios from 'axios';
import crypto from 'crypto';

const PAGSEGURO_API_KEY = process.env.PAGSEGURO_API_KEY;
const PAGSEGURO_API_URL = process.env.PAGSEGURO_API_URL || 'https://api.pagseguro.com';
const WEBHOOK_SECRET = process.env.WEBHOOK_SECRET || '';

const api = axios.create({
  baseURL: PAGSEGURO_API_URL,
  headers: {
    'Authorization': `Bearer ${PAGSEGURO_API_KEY}`,
    'Content-Type': 'application/json',
    'accept': 'application/json',
  },
});

export interface CreateOrderPayload {
  reference_id: string;
  customer: {
    name: string;
    email: string;
    tax_id?: string;
  };
  items: Array<{
    name: string;
    quantity: number;
    unit_amount: number;
  }>;
  notification_urls?: string[];
  payment_method?: {
    type: 'CREDIT_CARD';
    installments: number;
    capture: boolean;
    card: {
      token: string;
      holder: {
        name: string;
      };
    };
  };
}

/**
 * Cria uma nova ordem de pagamento (Checkout/Pedido) no PagBank
 */
export async function createOrder(payload: CreateOrderPayload) {
  try {
    const response = await api.post('/orders', payload);
    return response.data;
  } catch (error: any) {
    console.error('Erro ao criar ordem no PagBank:', error.response?.data || error.message);
    throw error;
  }
}

/**
 * Obtém detalhes de um pedido
 */
export async function getOrder(orderId: string) {
  try {
    const response = await api.get(`/orders/${orderId}`);
    return response.data;
  } catch (error: any) {
    console.error('Erro ao buscar pedido no PagBank:', error.response?.data || error.message);
    throw error;
  }
}

/**
 * Valida a assinatura do Webhook usando HMAC-SHA256
 */
export function validateWebhook(signature: string, body: string): boolean {
  if (!WEBHOOK_SECRET) {
    console.warn('[Webhook] WEBHOOK_SECRET não configurado, validação desabilitada');
    return true;
  }

  try {
    const hash = crypto
      .createHmac('sha256', WEBHOOK_SECRET)
      .update(body)
      .digest('hex');
    
    const isValid = hash === signature;
    
    if (!isValid) {
      console.error('[Webhook] Assinatura inválida. Esperado:', signature, 'Calculado:', hash);
    }
    
    return isValid;
  } catch (error) {
    console.error('[Webhook] Erro ao validar assinatura:', error);
    return false;
  }
}
