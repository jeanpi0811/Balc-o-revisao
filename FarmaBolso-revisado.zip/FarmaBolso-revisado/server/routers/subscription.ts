import { router, protectedProcedure } from '../_core/trpc';
import { z } from 'zod';
import * as pagseguroService from '../services/pagseguro';
import { getDb } from '../db';
import { subscriptions } from '../../drizzle/schema';
import { eq, desc } from 'drizzle-orm';

export const subscriptionRouter = router({
  /**
   * Criar pagamento único de acesso (30 dias)
   */
  createAccessPayment: protectedProcedure
    .input(
      z.object({
        cardToken: z.string(),
        holderName: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        const user = ctx.user;
        if (!user) {
          throw new Error('Usuário não autenticado');
        }

        const amountInCents = 990; // R$ 9,90

        // Criar pedido no PagBank
        const pagseguroResponse = await pagseguroService.createOrder({
          reference_id: `access_${user.id}_${Date.now()}`,
          customer: {
            name: user.name || 'Usuário Farma Bolso',
            email: user.email || '',
          },
          items: [
            {
              name: 'Acesso Premium Farma Bolso - 30 Dias',
              quantity: 1,
              unit_amount: amountInCents,
            }
          ],
          payment_method: {
            type: 'CREDIT_CARD',
            installments: 1,
            capture: true,
            card: {
              token: input.cardToken,
              holder: {
                name: input.holderName,
              },
            },
          },
        });

        // Registrar acesso no banco de dados (30 dias a partir de agora)
        const db = await getDb();
        if (!db) {
          throw new Error('Banco de dados não disponível');
        }

        const startDate = new Date();
        const endDate = new Date();
        endDate.setDate(startDate.getDate() + 30);

        await db.insert(subscriptions).values({
          userId: user.id,
          planType: 'monthly', // Mantemos o tipo 'monthly' internamente para representar os 30 dias
          pagseguroSubscriptionId: pagseguroResponse.id, // ID da Ordem/Pedido
          status: 'active',
          startDate: startDate,
          endDate: endDate,
        });

        return {
          success: true,
          orderId: pagseguroResponse.id,
          expiresAt: endDate,
        };
      } catch (error: any) {
        console.error('Erro ao processar pagamento único:', error);
        throw new Error('Falha ao processar pagamento com PagBank: ' + error.message);
      }
    }),

  /**
   * Obter status do acesso atual
   */
  getAccessStatus: protectedProcedure.query(async ({ ctx }) => {
    try {
      const user = ctx.user;
      if (!user) {
        return null;
      }

      const db = await getDb();
      if (!db) {
        console.warn('Banco de dados não disponível');
        return null;
      }

      const result = await db
        .select()
        .from(subscriptions)
        .where(eq(subscriptions.userId, user.id))
        .orderBy(desc(subscriptions.startDate))
        .limit(1);

      const access = result[0] || null;
      
      if (access && access.endDate && new Date(access.endDate) < new Date()) {
        return { ...access, status: 'expired' };
      }

      return access;
    } catch (error: any) {
      console.error('Erro ao buscar status de acesso:', error);
      throw new Error('Falha ao buscar status de acesso');
    }
  }),

  /**
   * Cancelar acesso/assinatura
   */
  cancelAccess: protectedProcedure.mutation(async ({ ctx }) => {
    try {
      const user = ctx.user;
      if (!user) {
        throw new Error('Usuário não autenticado');
      }

      const db = await getDb();
      if (!db) {
        throw new Error('Banco de dados não disponível');
      }

      // Encontrar subscrição ativa
      const result = await db
        .select()
        .from(subscriptions)
        .where(eq(subscriptions.userId, user.id))
        .orderBy(desc(subscriptions.startDate))
        .limit(1);

      const subscription = result[0];

      if (!subscription) {
        throw new Error('Nenhuma assinatura ativa encontrada');
      }

      // Atualizar status para cancelado
      await db
        .update(subscriptions)
        .set({ status: 'cancelled' })
        .where(eq(subscriptions.id, subscription.id));

      return { success: true };
    } catch (error: any) {
      console.error('Erro ao cancelar acesso:', error);
      throw new Error('Falha ao cancelar acesso: ' + error.message);
    }
  }),
});
