import { ScrollView, Text, View, TouchableOpacity, TextInput, Modal, Switch, Linking, Alert, Pressable } from 'react-native';
import { useState, useEffect } from 'react';
import { ScreenContainer } from '@/components/screen-container';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { useColors } from '@/hooks/use-colors';
import AsyncStorage from '@react-native-async-storage/async-storage';

const PROFILE_STORAGE_KEY = '@farma_bolso_profile';
const SUBSCRIPTION_STORAGE_KEY = '@farma_bolso_subscription';
const ADMIN_PASSWORD_KEY = '@farma_bolso_admin_password';
const NOTIFICATIONS_STORAGE_KEY = '@farma_bolso_notifications';

interface UserProfile {
  id?: string;
  name: string;
  email: string;
  password?: string;
  dateOfBirth?: string;
  gender?: 'male' | 'female' | 'other';
  phone?: string;
  cpf?: string;
  address?: string;
  city?: string;
  state?: string;
  zipCode?: string;
  emergencyContact?: string;
  emergencyPhone?: string;
  allergies?: string;
  chronicDiseases?: string;
  medications?: string;
}

interface Subscription {
  planType: 'free' | 'monthly' | 'quarterly' | 'semiannual' | 'annual';
  status: 'active' | 'inactive';
  startDate?: string;
  endDate?: string;
}

const PLANS = {
  free: { name: 'Gratuito', price: 'R$ 0,00', period: 'Ilimitado', icon: '🎁' },
  monthly: { name: 'Premium (30 dias)', price: 'R$ 9,90', period: '30 dias', icon: '⭐' },
};

export default function SettingsScreen() {
  const colors = useColors();
  const [profile, setProfile] = useState<UserProfile>({ name: '', email: '' });
  const [subscription, setSubscription] = useState<Subscription>({ planType: 'free', status: 'active' });
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  
  // Modals
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [showAdminLoginModal, setShowAdminLoginModal] = useState(false);
  const [showLGPDModal, setShowLGPDModal] = useState(false);
  const [showAboutModal, setShowAboutModal] = useState(false);
  
  // Form states
  const [editProfile, setEditProfile] = useState<UserProfile>({ name: '', email: '' });
  const [adminLoginPassword, setAdminLoginPassword] = useState('');

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const storedProfile = await AsyncStorage.getItem(PROFILE_STORAGE_KEY);
      const storedSubscription = await AsyncStorage.getItem(SUBSCRIPTION_STORAGE_KEY);
      const storedAdminPassword = await AsyncStorage.getItem(ADMIN_PASSWORD_KEY);
      const storedNotifications = await AsyncStorage.getItem(NOTIFICATIONS_STORAGE_KEY);

      if (storedProfile) {
        setProfile(JSON.parse(storedProfile));
      }
      if (storedSubscription) {
        setSubscription(JSON.parse(storedSubscription));
      }
      if (storedAdminPassword) {
        setAdminPassword(storedAdminPassword);
      }
      if (storedNotifications !== null) {
        setNotificationsEnabled(JSON.parse(storedNotifications));
      }
    } catch (error) {
      console.error('Error loading settings:', error);
    }
  };

  const handleSaveProfile = async () => {
    if (!editProfile.name || !editProfile.email) {
      Alert.alert('Erro', 'Nome e email são obrigatórios');
      return;
    }

    try {
      await AsyncStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(editProfile));
      setProfile(editProfile);
      setShowProfileModal(false);
      Alert.alert('Sucesso', 'Perfil atualizado com sucesso');
    } catch (error) {
      console.error('Error saving profile:', error);
      Alert.alert('Erro', 'Falha ao salvar perfil');
    }
  };

  const handleAdminLogin = async () => {
    if (!adminLoginPassword) {
      Alert.alert('Erro', 'Digite a senha de administrador');
      return;
    }

    if (adminLoginPassword === 'admin123') {
      setIsAdmin(true);
      setShowAdminLoginModal(false);
      setAdminLoginPassword('');
      Alert.alert('Sucesso', 'Acesso de administrador ativado');
    } else {
      Alert.alert('Erro', 'Senha de administrador incorreta');
    }
  };

  const handleSetAdminPassword = async (newPassword: string) => {
    if (!newPassword || newPassword.length < 6) {
      Alert.alert('Erro', 'Senha deve ter no mínimo 6 caracteres');
      return;
    }

    try {
      await AsyncStorage.setItem(ADMIN_PASSWORD_KEY, newPassword);
      setAdminPassword(newPassword);
      setShowAdminModal(false);
      Alert.alert('Sucesso', 'Senha de administrador atualizada');
    } catch (error) {
      console.error('Error saving admin password:', error);
      Alert.alert('Erro', 'Falha ao salvar senha');
    }
  };

  const handleUpgradePlan = async (planType: string) => {
    const newSubscription = {
      planType: planType as any,
      status: 'active' as const,
      startDate: new Date().toISOString(),
      endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
    };

    try {
      await AsyncStorage.setItem(SUBSCRIPTION_STORAGE_KEY, JSON.stringify(newSubscription));
      setSubscription(newSubscription);
      setShowSubscriptionModal(false);
      Alert.alert('Sucesso', `Acesso Premium ativado por 30 dias!\n\nNota: Em produção, isso abriria o PagSeguro para pagamento único.`);
    } catch (error) {
      console.error('Error upgrading plan:', error);
      Alert.alert('Erro', 'Falha ao atualizar plano');
    }
  };

  const handleNotificationsToggle = async (value: boolean) => {
    try {
      setNotificationsEnabled(value);
      await AsyncStorage.setItem(NOTIFICATIONS_STORAGE_KEY, JSON.stringify(value));
    } catch (error) {
      console.error('Error saving notifications setting:', error);
    }
  };

  const SettingItem = ({
    icon,
    title,
    subtitle,
    onPress,
    rightElement,
  }: {
    icon: any;
    title: string;
    subtitle?: string;
    onPress: () => void;
    rightElement?: React.ReactNode;
  }) => (
    <TouchableOpacity
      style={{
        backgroundColor: colors.background,
        borderRadius: 16,
        padding: 16,
        marginBottom: 12,
        borderWidth: 1,
        borderColor: colors.border,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.05,
        shadowRadius: 8,
        elevation: 2,
      }}
      onPress={onPress}
      activeOpacity={0.6}
    >
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14, flex: 1 }}>
        <View style={{
          width: 44,
          height: 44,
          borderRadius: 12,
          backgroundColor: colors.tint + '15',
          justifyContent: 'center',
          alignItems: 'center',
        }}>
          <IconSymbol size={24} name={icon} color={colors.tint} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 16, fontWeight: '600', color: colors.text }}>
            {title}
          </Text>
          {subtitle && (
            <Text style={{ fontSize: 12, color: colors.muted, marginTop: 4 }}>
              {subtitle}
            </Text>
          )}
        </View>
      </View>
      {rightElement || <IconSymbol size={20} name="chevron.right" color={colors.muted} />}
    </TouchableOpacity>
  );

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} style={{ flex: 1, paddingHorizontal: 16 }}>
        {/* Header com Avatar */}
        <View style={{ marginTop: 24, marginBottom: 32, alignItems: 'center' }}>
          <View style={{
            width: 80,
            height: 80,
            borderRadius: 40,
            backgroundColor: colors.tint + '20',
            justifyContent: 'center',
            alignItems: 'center',
            marginBottom: 16,
            borderWidth: 2,
            borderColor: colors.tint + '40',
          }}>
            <Text style={{ fontSize: 40 }}>👤</Text>
          </View>
          <Text style={{ fontSize: 20, fontWeight: '700', color: colors.text, marginBottom: 4 }}>
            {profile.name || 'Bem-vindo!'}
          </Text>
          <Text style={{ fontSize: 14, color: colors.muted }}>
            {profile.email || 'Configure seu perfil'}
          </Text>
        </View>

        {/* Perfil Section */}
        <View style={{ marginBottom: 28 }}>
          <Text style={{ fontSize: 14, fontWeight: '700', color: colors.text, marginBottom: 12, textTransform: 'uppercase', letterSpacing: 0.5 }}>
            👤 Perfil
          </Text>
          <SettingItem
            icon="person.fill"
            title="Meu Perfil"
            subtitle={profile.name || 'Clique para adicionar seu nome'}
            onPress={() => {
              setEditProfile(profile);
              setShowProfileModal(true);
            }}
          />
        </View>

        {/* Assinatura Section */}
        <View style={{ marginBottom: 28 }}>
          <Text style={{ fontSize: 14, fontWeight: '700', color: colors.text, marginBottom: 12, textTransform: 'uppercase', letterSpacing: 0.5 }}>
            ⭐ Assinatura
          </Text>
          <View
            style={{
              backgroundColor: subscription.planType === 'free' 
                ? 'rgba(255, 193, 7, 0.1)' 
                : 'rgba(76, 175, 80, 0.1)',
              borderRadius: 16,
              padding: 20,
              marginBottom: 12,
              borderLeftWidth: 4,
              borderLeftColor: subscription.planType === 'free' ? '#FFC107' : '#4CAF50',
              borderWidth: 1,
              borderColor: subscription.planType === 'free' ? '#FFD54F' : '#81C784',
            }}
          >
            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
              <Text style={{ fontSize: 32, marginRight: 12 }}>
                {PLANS[subscription.planType as keyof typeof PLANS].icon}
              </Text>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 16, fontWeight: '700', color: subscription.planType === 'free' ? '#F57F17' : '#2E7D32', marginBottom: 4 }}>
                  {PLANS[subscription.planType as keyof typeof PLANS].name}
                </Text>
                <Text style={{ fontSize: 12, color: subscription.planType === 'free' ? '#F57F17' : '#2E7D32' }}>
                  {PLANS[subscription.planType as keyof typeof PLANS].period}
                </Text>
              </View>
            </View>
            <Text style={{ fontSize: 20, fontWeight: '700', color: subscription.planType === 'free' ? '#F57F17' : '#2E7D32', marginBottom: 16 }}>
              {PLANS[subscription.planType as keyof typeof PLANS].price}
            </Text>
            <TouchableOpacity
              onPress={() => setShowSubscriptionModal(true)}
              style={{
                backgroundColor: colors.tint,
                paddingHorizontal: 16,
                paddingVertical: 12,
                borderRadius: 12,
                alignSelf: 'flex-start',
              }}
            >
              <Text style={{ fontSize: 13, fontWeight: '600', color: '#fff' }}>
                {subscription.planType === 'free' ? '🚀 Upgrade Agora' : '⚙️ Gerenciar'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Preferências Section */}
        <View style={{ marginBottom: 28 }}>
          <Text style={{ fontSize: 14, fontWeight: '700', color: colors.text, marginBottom: 12, textTransform: 'uppercase', letterSpacing: 0.5 }}>
            🔔 Preferências
          </Text>
          <View
            style={{
              backgroundColor: colors.background,
              borderRadius: 16,
              padding: 16,
              marginBottom: 12,
              borderWidth: 1,
              borderColor: colors.border,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.05,
              shadowRadius: 8,
              elevation: 2,
            }}
          >
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14, flex: 1 }}>
              <View style={{
                width: 44,
                height: 44,
                borderRadius: 12,
                backgroundColor: colors.tint + '15',
                justifyContent: 'center',
                alignItems: 'center',
              }}>
                <IconSymbol size={24} name="bell.fill" color={colors.tint} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 16, fontWeight: '600', color: colors.text }}>
                  Notificações
                </Text>
                <Text style={{ fontSize: 12, color: colors.muted, marginTop: 4 }}>
                  Lembretes de medicamentos
                </Text>
              </View>
            </View>
            <Switch
              value={notificationsEnabled}
              onValueChange={handleNotificationsToggle}
              trackColor={{ false: colors.border, true: colors.tint + '40' }}
              thumbColor={notificationsEnabled ? colors.tint : colors.muted}
            />
          </View>
        </View>

        {/* Admin Section */}
        {isAdmin && (
          <View style={{ marginBottom: 28 }}>
            <Text style={{ fontSize: 14, fontWeight: '700', color: colors.text, marginBottom: 12, textTransform: 'uppercase', letterSpacing: 0.5 }}>
              🔐 Administração
            </Text>
            <SettingItem
              icon="lock.fill"
              title="Gerenciar Senha Admin"
              subtitle="Alterar senha de administrador"
              onPress={() => setShowAdminModal(true)}
            />
            <SettingItem
              icon="chart.bar.fill"
              title="Estatísticas"
              subtitle="Ver dados de uso do app"
              onPress={() => Alert.alert('Estatísticas', 'Funcionalidade disponível em breve')}
            />
            <SettingItem
              icon="person.2.fill"
              title="Gerenciar Usuários"
              subtitle="Visualizar e gerenciar usuários"
              onPress={() => Alert.alert('Gerenciar Usuários', 'Funcionalidade disponível em breve')}
            />
          </View>
        )}

        {/* Suporte Section */}
        <View style={{ marginBottom: 28 }}>
          <Text style={{ fontSize: 14, fontWeight: '700', color: colors.text, marginBottom: 12, textTransform: 'uppercase', letterSpacing: 0.5 }}>
            💬 Suporte
          </Text>
          <SettingItem
            icon="envelope.fill"
            title="Suporte por E-mail"
            subtitle="suporte@farmabolso.com.br"
            onPress={() => Linking.openURL('mailto:suporte@farmabolso.com.br')}
          />
          {!isAdmin && (
            <SettingItem
              icon="lock.fill"
              title="Acesso de Administrador"
              subtitle="Login para gerenciar o app"
              onPress={() => setShowAdminLoginModal(true)}
            />
          )}
          {isAdmin && (
            <SettingItem
              icon="rectangle.portrait.and.arrow.right.fill"
              title="Sair do Modo Admin"
              subtitle="Desativar acesso administrativo"
              onPress={() => {
                setIsAdmin(false);
                Alert.alert('Sucesso', 'Modo administrador desativado');
              }}
            />
          )}
          <SettingItem
            icon="rectangle.portrait.and.arrow.right.fill"
            title="Sair da Conta"
            subtitle="Encerrar sessão no dispositivo"
            onPress={() => Alert.alert('Sair', 'Deseja realmente sair da conta?', [
              { text: 'Cancelar', style: 'cancel' },
              { text: 'Sair', style: 'destructive', onPress: () => console.log('Logout') },
            ])}
          />
        </View>

        {/* Legal Section */}
        <View style={{ marginBottom: 28 }}>
          <Text style={{ fontSize: 14, fontWeight: '700', color: colors.text, marginBottom: 12, textTransform: 'uppercase', letterSpacing: 0.5 }}>
            ⚖️ Legal
          </Text>
          <SettingItem
            icon="doc.text.fill"
            title="LGPD e Privacidade"
            subtitle="Lei Geral de Proteção de Dados"
            onPress={() => setShowLGPDModal(true)}
          />
        </View>

        {/* About Section */}
        <View style={{ marginBottom: 40 }}>
          <Text style={{ fontSize: 14, fontWeight: '700', color: colors.text, marginBottom: 12, textTransform: 'uppercase', letterSpacing: 0.5 }}>
            ℹ️ Sobre
          </Text>
          <SettingItem
            icon="info.circle.fill"
            title="Sobre o App"
            subtitle="Versão 2.0.0"
            onPress={() => setShowAboutModal(true)}
          />
        </View>
      </ScrollView>

      {/* Profile Modal */}
      <Modal
        visible={showProfileModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowProfileModal(false)}
      >
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' }}>
          <View style={{ backgroundColor: colors.background, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, paddingBottom: 40 }}>
            <View style={{ height: 4, width: 40, backgroundColor: colors.muted, borderRadius: 2, alignSelf: 'center', marginBottom: 20 }} />
            <Text style={{ fontSize: 20, fontWeight: '700', color: colors.text, marginBottom: 20 }}>
              Editar Perfil
            </Text>

            <ScrollView style={{ maxHeight: 400 }}>
              {/* Nome */}
              <Text style={{ fontSize: 13, fontWeight: '600', color: colors.text, marginBottom: 8 }}>
                Nome *
              </Text>
              <TextInput
                style={{
                  borderWidth: 1,
                  borderColor: colors.border,
                  borderRadius: 12,
                  paddingHorizontal: 14,
                  paddingVertical: 12,
                  marginBottom: 16,
                  color: colors.text,
                  fontSize: 14,
                  backgroundColor: colors.background,
                }}
                placeholder="Seu nome completo"
                placeholderTextColor={colors.muted}
                value={editProfile.name}
                onChangeText={(text) => setEditProfile({ ...editProfile, name: text })}
              />

              {/* Email */}
              <Text style={{ fontSize: 13, fontWeight: '600', color: colors.text, marginBottom: 8 }}>
                Email *
              </Text>
              <TextInput
                style={{
                  borderWidth: 1,
                  borderColor: colors.border,
                  borderRadius: 12,
                  paddingHorizontal: 14,
                  paddingVertical: 12,
                  marginBottom: 16,
                  color: colors.text,
                  fontSize: 14,
                  backgroundColor: colors.background,
                }}
                placeholder="seu@email.com"
                placeholderTextColor={colors.muted}
                value={editProfile.email}
                onChangeText={(text) => setEditProfile({ ...editProfile, email: text })}
                keyboardType="email-address"
              />

              {/* Phone */}
              <Text style={{ fontSize: 13, fontWeight: '600', color: colors.text, marginBottom: 8 }}>
                Telefone
              </Text>
              <TextInput
                style={{
                  borderWidth: 1,
                  borderColor: colors.border,
                  borderRadius: 12,
                  paddingHorizontal: 14,
                  paddingVertical: 12,
                  marginBottom: 16,
                  color: colors.text,
                  fontSize: 14,
                  backgroundColor: colors.background,
                }}
                placeholder="(11) 99999-9999"
                placeholderTextColor={colors.muted}
                value={editProfile.phone}
                onChangeText={(text) => setEditProfile({ ...editProfile, phone: text })}
                keyboardType="phone-pad"
              />

              {/* CPF */}
              <Text style={{ fontSize: 13, fontWeight: '600', color: colors.text, marginBottom: 8 }}>
                CPF
              </Text>
              <TextInput
                style={{
                  borderWidth: 1,
                  borderColor: colors.border,
                  borderRadius: 12,
                  paddingHorizontal: 14,
                  paddingVertical: 12,
                  marginBottom: 20,
                  color: colors.text,
                  fontSize: 14,
                  backgroundColor: colors.background,
                }}
                placeholder="000.000.000-00"
                placeholderTextColor={colors.muted}
                value={editProfile.cpf}
                onChangeText={(text) => setEditProfile({ ...editProfile, cpf: text })}
              />
            </ScrollView>

            {/* Buttons */}
            <View style={{ flexDirection: 'row', gap: 12 }}>
              <TouchableOpacity
                onPress={() => setShowProfileModal(false)}
                style={{
                  flex: 1,
                  paddingVertical: 14,
                  borderRadius: 12,
                  borderWidth: 1,
                  borderColor: colors.border,
                }}
              >
                <Text style={{ color: colors.text, fontWeight: '600', textAlign: 'center' }}>
                  Cancelar
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={handleSaveProfile}
                style={{
                  flex: 1,
                  paddingVertical: 14,
                  borderRadius: 12,
                  backgroundColor: colors.tint,
                }}
              >
                <Text style={{ color: '#fff', fontWeight: '600', textAlign: 'center' }}>
                  Salvar
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Subscription Modal */}
      <Modal
        visible={showSubscriptionModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowSubscriptionModal(false)}
      >
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' }}>
          <View style={{ backgroundColor: colors.background, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, paddingBottom: 40 }}>
            <View style={{ height: 4, width: 40, backgroundColor: colors.muted, borderRadius: 2, alignSelf: 'center', marginBottom: 20 }} />
            <Text style={{ fontSize: 20, fontWeight: '700', color: colors.text, marginBottom: 20 }}>
              Escolha seu Plano
            </Text>

            {/* Plan Card */}
            <TouchableOpacity
              onPress={() => handleUpgradePlan('monthly')}
              style={{
                backgroundColor: 'rgba(76, 175, 80, 0.1)',
                borderRadius: 16,
                padding: 20,
                marginBottom: 16,
                borderWidth: 2,
                borderColor: '#4CAF50',
              }}
            >
              <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
                <Text style={{ fontSize: 32, marginRight: 12 }}>⭐</Text>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 16, fontWeight: '700', color: '#2E7D32', marginBottom: 4 }}>
                    Premium - 30 Dias
                  </Text>
                  <Text style={{ fontSize: 12, color: '#2E7D32' }}>
                    Acesso completo ao app
                  </Text>
                </View>
              </View>
              <Text style={{ fontSize: 24, fontWeight: '700', color: '#2E7D32', marginBottom: 12 }}>
                R$ 9,90
              </Text>
              <Text style={{ fontSize: 12, color: '#2E7D32', marginBottom: 12 }}>
                ✓ Consultas ilimitadas\n✓ Análise de exames\n✓ IA avançada
              </Text>
              <View style={{ backgroundColor: '#4CAF50', paddingVertical: 12, borderRadius: 12, alignItems: 'center' }}>
                <Text style={{ color: '#fff', fontWeight: '600' }}>
                  Ativar Premium
                </Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => setShowSubscriptionModal(false)}
              style={{
                paddingVertical: 14,
                borderRadius: 12,
                borderWidth: 1,
                borderColor: colors.border,
              }}
            >
              <Text style={{ color: colors.text, fontWeight: '600', textAlign: 'center' }}>
                Cancelar
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Admin Modal */}
      <Modal
        visible={showAdminModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowAdminModal(false)}
      >
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' }}>
          <View style={{ backgroundColor: colors.background, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, paddingBottom: 40 }}>
            <View style={{ height: 4, width: 40, backgroundColor: colors.muted, borderRadius: 2, alignSelf: 'center', marginBottom: 20 }} />
            <Text style={{ fontSize: 20, fontWeight: '700', color: colors.text, marginBottom: 20 }}>
              Alterar Senha Admin
            </Text>

            <TextInput
              style={{
                borderWidth: 1,
                borderColor: colors.border,
                borderRadius: 12,
                paddingHorizontal: 14,
                paddingVertical: 12,
                marginBottom: 20,
                color: colors.text,
                fontSize: 14,
                backgroundColor: colors.background,
              }}
              placeholder="Nova senha"
              placeholderTextColor={colors.muted}
              secureTextEntry
              onChangeText={(text) => setAdminPassword(text)}
            />

            <View style={{ flexDirection: 'row', gap: 12 }}>
              <TouchableOpacity
                onPress={() => setShowAdminModal(false)}
                style={{
                  flex: 1,
                  paddingVertical: 14,
                  borderRadius: 12,
                  borderWidth: 1,
                  borderColor: colors.border,
                }}
              >
                <Text style={{ color: colors.text, fontWeight: '600', textAlign: 'center' }}>
                  Cancelar
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => handleSetAdminPassword(adminPassword)}
                style={{
                  flex: 1,
                  paddingVertical: 14,
                  borderRadius: 12,
                  backgroundColor: colors.tint,
                }}
              >
                <Text style={{ color: '#fff', fontWeight: '600', textAlign: 'center' }}>
                  Salvar
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Admin Login Modal */}
      <Modal
        visible={showAdminLoginModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowAdminLoginModal(false)}
      >
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' }}>
          <View style={{ backgroundColor: colors.background, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, paddingBottom: 40 }}>
            <View style={{ height: 4, width: 40, backgroundColor: colors.muted, borderRadius: 2, alignSelf: 'center', marginBottom: 20 }} />
            <Text style={{ fontSize: 20, fontWeight: '700', color: colors.text, marginBottom: 20 }}>
              Acesso de Administrador
            </Text>

            <TextInput
              style={{
                borderWidth: 1,
                borderColor: colors.border,
                borderRadius: 12,
                paddingHorizontal: 14,
                paddingVertical: 12,
                marginBottom: 20,
                color: colors.text,
                fontSize: 14,
                backgroundColor: colors.background,
              }}
              placeholder="Digite a senha"
              placeholderTextColor={colors.muted}
              secureTextEntry
              value={adminLoginPassword}
              onChangeText={setAdminLoginPassword}
            />

            <View style={{ flexDirection: 'row', gap: 12 }}>
              <TouchableOpacity
                onPress={() => setShowAdminLoginModal(false)}
                style={{
                  flex: 1,
                  paddingVertical: 14,
                  borderRadius: 12,
                  borderWidth: 1,
                  borderColor: colors.border,
                }}
              >
                <Text style={{ color: colors.text, fontWeight: '600', textAlign: 'center' }}>
                  Cancelar
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={handleAdminLogin}
                style={{
                  flex: 1,
                  paddingVertical: 14,
                  borderRadius: 12,
                  backgroundColor: colors.tint,
                }}
              >
                <Text style={{ color: '#fff', fontWeight: '600', textAlign: 'center' }}>
                  Entrar
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* LGPD Modal */}
      <Modal
        visible={showLGPDModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowLGPDModal(false)}
      >
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' }}>
          <View style={{ backgroundColor: colors.background, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, paddingBottom: 40, maxHeight: '80%' }}>
            <View style={{ height: 4, width: 40, backgroundColor: colors.muted, borderRadius: 2, alignSelf: 'center', marginBottom: 20 }} />
            <Text style={{ fontSize: 20, fontWeight: '700', color: colors.text, marginBottom: 16 }}>
              LGPD e Privacidade
            </Text>

            <ScrollView style={{ marginBottom: 20 }}>
              <Text style={{ fontSize: 14, color: colors.text, lineHeight: 22 }}>
                A Lei Geral de Proteção de Dados (LGPD) é uma legislação que regulamenta o tratamento de dados pessoais no Brasil.

                {'\n\n'}Nós respeitamos sua privacidade e nos comprometemos a proteger seus dados pessoais de acordo com a LGPD.

                {'\n\n'}Seus dados são utilizados apenas para melhorar sua experiência no app e nunca serão compartilhados com terceiros sem seu consentimento.
              </Text>
            </ScrollView>

            <TouchableOpacity
              onPress={() => setShowLGPDModal(false)}
              style={{
                paddingVertical: 14,
                borderRadius: 12,
                backgroundColor: colors.tint,
              }}
            >
              <Text style={{ color: '#fff', fontWeight: '600', textAlign: 'center' }}>
                Entendi
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* About Modal */}
      <Modal
        visible={showAboutModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowAboutModal(false)}
      >
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' }}>
          <View style={{ backgroundColor: colors.background, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, paddingBottom: 40, maxHeight: '80%' }}>
            <View style={{ height: 4, width: 40, backgroundColor: colors.muted, borderRadius: 2, alignSelf: 'center', marginBottom: 20 }} />
            <Text style={{ fontSize: 20, fontWeight: '700', color: colors.text, marginBottom: 16 }}>
              Sobre o App
            </Text>

            <ScrollView style={{ marginBottom: 20 }}>
              <Text style={{ fontSize: 14, color: colors.text, lineHeight: 22 }}>
                <Text style={{ fontWeight: '700' }}>Farma Bolso v2.0.0</Text>

                {'\n\n'}Um app inovador para ajudar você a gerenciar seus medicamentos, consultar bulas e análises de exames com a ajuda de inteligência artificial.

                {'\n\n'}Desenvolvido com ❤️ para sua saúde.

                {'\n\n'}© 2024 Farma Bolso. Todos os direitos reservados.
              </Text>
            </ScrollView>

            <TouchableOpacity
              onPress={() => setShowAboutModal(false)}
              style={{
                paddingVertical: 14,
                borderRadius: 12,
                backgroundColor: colors.tint,
              }}
            >
              <Text style={{ color: '#fff', fontWeight: '600', textAlign: 'center' }}>
                Fechar
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}
