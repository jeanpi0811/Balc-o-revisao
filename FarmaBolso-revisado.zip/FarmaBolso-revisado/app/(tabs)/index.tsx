import { ScrollView, Text, View, TextInput, FlatList, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { useColors } from '@/hooks/use-colors';
import { searchMedicationsWithCache, MedicationSearchResult } from '@/lib/services/bulario-service';

export default function BulasScreen() {
  const colors = useColors();
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState('');
  const [results, setResults] = useState<MedicationSearchResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      setResults([]);
      setHasSearched(false);
      return;
    }

    setIsLoading(true);
    setHasSearched(true);

    try {
      const data = await searchMedicationsWithCache(searchQuery);
      setResults(data);
    } catch (error) {
      console.error('Search error:', error);
      setResults([]);
    } finally {
      setIsLoading(false);
    }
  };

  const renderMedicineCard = ({ item }: { item: MedicationSearchResult }) => (
    <TouchableOpacity
      className="bg-surface rounded-lg p-4 mb-3 border border-border"
      activeOpacity={0.7}
      onPress={() => router.push({
        pathname: '/medicine-details',
        params: { processo: item.processo, nome: item.nomeComercial }
      })}
    >
      <Text className="text-lg font-semibold text-foreground mb-1">
        {item.nomeComercial}
      </Text>
      <Text className="text-sm text-muted mb-2">
        Princípio Ativo: {item.principioAtivo}
      </Text>
      <Text className="text-xs text-muted">
        Laboratório: {item.laboratorio}
      </Text>
      <View className="mt-3 bg-primary rounded-lg py-2 px-4">
        <Text className="text-white text-center font-semibold text-sm">
          Ver Detalhes e Bula
        </Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <ScreenContainer className="p-4">
      {/* Search Bar */}
      <View className="mb-4">
        <View className="flex-row items-center bg-surface border border-border rounded-lg px-3 py-2">
          <IconSymbol size={20} name="magnifyingglass" color={colors.muted} />
          <TextInput
            className="flex-1 ml-2 text-foreground"
            placeholder="Buscar medicamento..."
            placeholderTextColor={colors.muted}
            value={searchQuery}
            onChangeText={setSearchQuery}
            onSubmitEditing={handleSearch}
            returnKeyType="search"
          />
        </View>
      </View>

      {/* Results */}
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={colors.primary} />
          <Text className="text-muted mt-2">Buscando medicamentos...</Text>
        </View>
      ) : results.length > 0 ? (
        <FlatList
          data={results}
          renderItem={renderMedicineCard}
          keyExtractor={(item) => item.processo}
          scrollEnabled={false}
        />
      ) : hasSearched ? (
        <View className="flex-1 items-center justify-center">
          <IconSymbol size={48} name="magnifyingglass" color={colors.muted} />
          <Text className="text-muted mt-4 text-center">
            Nenhum medicamento encontrado para "{searchQuery}"
          </Text>
        </View>
      ) : (
        <ScrollView className="flex-1">
          <View className="items-center justify-center py-12">
            <IconSymbol size={64} name="book.fill" color={colors.muted} />
            <Text className="text-foreground text-xl font-semibold mt-4">
              Bulas de Medicamentos
            </Text>
            <Text className="text-muted text-center mt-2 px-4">
              Busque o nome de um medicamento para consultar sua bula completa
            </Text>
          </View>
        </ScrollView>
      )}
    </ScreenContainer>
  );
}
