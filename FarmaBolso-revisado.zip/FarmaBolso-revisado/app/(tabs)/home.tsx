import { ScrollView, Text, View, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import { useEffect, useState } from 'react';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { useColors } from '@/hooks/use-colors';
import { ScreenContainer } from '@/components/screen-container';

const { width } = Dimensions.get('window');

const QUICK_ACCESS_ROUTES = {
  index: '/',
  exams: '/exams',
  ai: '/ai',
  home: '/home',
} as const;

interface UserProfile {
  name?: string;
  email?: string;
}

interface DailyUsage {
  totalCount: number;
  bulasSearchCount: number;
  examsSearchCount: number;
  aiQueriesCount: number;
}

export default function HomeScreen() {
  const router = useRouter();
  const colors = useColors();
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [dailyUsage, setDailyUsage] = useState<DailyUsage>({
    totalCount: 0,
    bulasSearchCount: 0,
    examsSearchCount: 0,
    aiQueriesCount: 0,
  });
  const [planType, setPlanType] = useState<string>('free');
  const [remainingQuota, setRemainingQuota] = useState<number>(3);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    try {
      const profile = await AsyncStorage.getItem('@farma_bolso_profile');
      if (profile) {
        setUserProfile(JSON.parse(profile));
      }

      const today = new Date().toISOString().split('T')[0];
      const usage = await AsyncStorage.getItem(`@farma_bolso_usage_${today}`);
      if (usage) {
        setDailyUsage(JSON.parse(usage));
      }

      const subscription = await AsyncStorage.getItem('@farma_bolso_subscription');
      let currentPlan = 'free';
      if (subscription) {
        const sub = JSON.parse(subscription);
        currentPlan = sub.planType || 'free';
        setPlanType(currentPlan);
      }

      if (currentPlan === 'free') {
        const usage_data = usage ? JSON.parse(usage) : { totalCount: 0 };
        setRemainingQuota(Math.max(0, 3 - usage_data.totalCount));
      } else {
        setRemainingQuota(999);
      }
    } catch (error) {
      console.error('Error loading user data:', error);
    }
  };

  const handleQuickAccess = (screen: keyof typeof QUICK_ACCESS_ROUTES) => {
    router.push(QUICK_ACCESS_ROUTES[screen]);
  };

  const handleUpgrade = () => {
    router.push('/(tabs)/settings');
  };

  return (
    <ScreenContainer>
      <ScrollView 
        showsVerticalScrollIndicator={false}
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: 40 }}
      >
        {/* Modern Header */}
        <View style={[styles.header, { backgroundColor: colors.tint }]}>
          <View style={styles.headerContent}>
            <View>
              <Text style={styles.greetingText}>
                Olá, {userProfile?.name?.split(' ')[0] || 'Usuário'}! 👋
              </Text>
              <Text style={styles.subGreetingText}>
                Como podemos ajudar sua saúde hoje?
              </Text>
            </View>
            <TouchableOpacity 
              onPress={() => router.push('/(tabs)/settings')}
              style={styles.avatarMini}
            >
              <Text style={{ fontSize: 20 }}>👤</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Status Card - Floating Style */}
        <View style={styles.statusCardContainer}>
          <View
            style={[
              styles.statusCard,
              { 
                backgroundColor: colors.background,
                borderColor: planType === 'free' ? '#FFD54F' : '#81C784',
                borderLeftColor: planType === 'free' ? '#FFC107' : '#4CAF50',
              }
            ]}
          >
            <View style={styles.statusInfo}>
              <View style={[styles.planBadge, { backgroundColor: planType === 'free' ? '#FFF3CD' : '#D4EDDA' }]}>
                <Text style={[styles.planBadgeText, { color: planType === 'free' ? '#856404' : '#155724' }]}>
                  {planType === 'free' ? 'GRATUITO' : 'PREMIUM'}
                </Text>
              </View>
              <Text style={[styles.statusTitle, { color: colors.text }]}>
                {planType === 'free' ? 'Limite Diário' : 'Acesso Ilimitado'}
              </Text>
              <Text style={[styles.statusSubtitle, { color: colors.muted }]}>
                {planType === 'free' 
                  ? `${remainingQuota} de 3 consultas disponíveis` 
                  : 'Aproveite todos os recursos'}
              </Text>
            </View>
            {planType === 'free' && (
              <TouchableOpacity
                onPress={handleUpgrade}
                style={[styles.upgradeBtn, { backgroundColor: colors.tint }]}
              >
                <Text style={styles.upgradeBtnText}>Upgrade</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* Quick Access Grid */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Acesso Rápido</Text>
          <View style={styles.grid}>
            <QuickAccessItem 
              title="Bulas" 
              icon="book.fill" 
              color="#4A90E2" 
              onPress={() => handleQuickAccess('index')}
              colors={colors}
            />
            <QuickAccessItem 
              title="Exames" 
              icon="doc.text.fill" 
              color="#50E3C2" 
              onPress={() => handleQuickAccess('exams')}
              colors={colors}
            />
            <QuickAccessItem 
              title="IA Saúde" 
              icon="sparkles" 
              color="#BD10E0" 
              onPress={() => handleQuickAccess('ai')}
              colors={colors}
            />
            <QuickAccessItem 
              title="Histórico" 
              icon="clock.fill" 
              color="#F5A623" 
              onPress={() => handleQuickAccess('home')}
              colors={colors}
            />
          </View>
        </View>

        {/* Usage Stats Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>Resumo de Hoje</Text>
            <IconSymbol name="chart.bar.fill" size={16} color={colors.muted} />
          </View>
          <View style={styles.statsContainer}>
            <StatBox 
              label="Bulas" 
              value={dailyUsage.bulasSearchCount} 
              icon="book.fill" 
              colors={colors} 
            />
            <StatBox 
              label="Exames" 
              value={dailyUsage.examsSearchCount} 
              icon="doc.text.fill" 
              colors={colors} 
            />
            <StatBox 
              label="IA" 
              value={dailyUsage.aiQueriesCount} 
              icon="sparkles" 
              colors={colors} 
            />
          </View>
        </View>

        {/* Health Tip Card */}
        <View style={styles.section}>
          <TouchableOpacity 
            style={[styles.tipCard, { backgroundColor: colors.tint + '10', borderColor: colors.tint + '20' }]}
            activeOpacity={0.8}
          >
            <View style={styles.tipIconContainer}>
              <IconSymbol name="lightbulb.fill" size={24} color={colors.tint} />
            </View>
            <View style={styles.tipContent}>
              <Text style={[styles.tipTitle, { color: colors.text }]}>Dica do Dia</Text>
              <Text style={[styles.tipText, { color: colors.muted }]}>
                Mantenha seus exames organizados para um melhor acompanhamento médico. Use nossa IA para entender os resultados!
              </Text>
            </View>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

function QuickAccessItem({ title, icon, color, onPress, colors }: any) {
  return (
    <TouchableOpacity 
      style={[styles.gridItem, { backgroundColor: colors.background, borderColor: colors.border }]} 
      onPress={onPress}
      activeOpacity={0.7}
    >
      <View style={[styles.gridIconContainer, { backgroundColor: color + '15' }]}>
        <IconSymbol name={icon} size={28} color={color} />
      </View>
      <Text style={[styles.gridText, { color: colors.text }]}>{title}</Text>
    </TouchableOpacity>
  );
}

function StatBox({ label, value, icon, colors }: any) {
  return (
    <View style={[styles.statBox, { backgroundColor: colors.background, borderColor: colors.border }]}>
      <IconSymbol size={20} name={icon} color={colors.tint} />
      <Text style={[styles.statValue, { color: colors.text }]}>{value}</Text>
      <Text style={[styles.statLabel, { color: colors.muted }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    height: 180,
    paddingTop: 60,
    paddingHorizontal: 20,
    borderBottomLeftRadius: 32,
    borderBottomRightRadius: 32,
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  greetingText: {
    fontSize: 24,
    fontWeight: '800',
    color: '#fff',
    marginBottom: 4,
  },
  subGreetingText: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
  },
  avatarMini: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  statusCardContainer: {
    paddingHorizontal: 20,
    marginTop: -40,
    marginBottom: 24,
  },
  statusCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    borderRadius: 20,
    borderWidth: 1,
    borderLeftWidth: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 5,
  },
  statusInfo: {
    flex: 1,
  },
  planBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 6,
    marginBottom: 8,
  },
  planBadgeText: {
    fontSize: 10,
    fontWeight: '800',
  },
  statusTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 2,
  },
  statusSubtitle: {
    fontSize: 12,
  },
  upgradeBtn: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 12,
  },
  upgradeBtnText: {
    color: '#fff',
    fontSize: 13,
    fontWeight: '700',
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 16,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  gridItem: {
    width: (width - 52) / 2,
    padding: 16,
    borderRadius: 20,
    borderWidth: 1,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  gridIconContainer: {
    width: 56,
    height: 56,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  gridText: {
    fontSize: 14,
    fontWeight: '600',
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 12,
  },
  statBox: {
    flex: 1,
    padding: 16,
    borderRadius: 20,
    borderWidth: 1,
    alignItems: 'center',
  },
  statValue: {
    fontSize: 20,
    fontWeight: '800',
    marginTop: 8,
    marginBottom: 2,
  },
  statLabel: {
    fontSize: 11,
    fontWeight: '500',
  },
  tipCard: {
    flexDirection: 'row',
    padding: 20,
    borderRadius: 20,
    borderWidth: 1,
    alignItems: 'center',
  },
  tipIconContainer: {
    marginRight: 16,
  },
  tipContent: {
    flex: 1,
  },
  tipTitle: {
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 4,
  },
  tipText: {
    fontSize: 13,
    lineHeight: 18,
  },
});
