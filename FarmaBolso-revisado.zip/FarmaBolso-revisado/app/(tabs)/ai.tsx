import { ScrollView, Text, View, FlatList, TextInput, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useState, useRef, useEffect } from 'react';
import { ScreenContainer } from '@/components/screen-container';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { useColors } from '@/hooks/use-colors';
import { sendChatMessage, createChatMessage, ChatMessage } from '@/lib/services/ai-service';
import AsyncStorage from '@react-native-async-storage/async-storage';

const CHAT_STORAGE_KEY = '@farma_bolso_ai_chat';

export default function AIScreen() {
  const colors = useColors();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const flatListRef = useRef<FlatList>(null);

  // Load chat history on mount
  useEffect(() => {
    loadChatHistory();
  }, []);

  const loadChatHistory = async () => {
    try {
      const stored = await AsyncStorage.getItem(CHAT_STORAGE_KEY);
      if (stored) {
        setMessages(JSON.parse(stored));
      }
    } catch (error) {
      console.error('Error loading chat history:', error);
    }
  };

  const saveChatHistory = async (newMessages: ChatMessage[]) => {
    try {
      await AsyncStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(newMessages));
    } catch (error) {
      console.error('Error saving chat history:', error);
    }
  };

  const handleSendMessage = async () => {
    if (!inputText.trim()) return;

    // Add user message
    const userMessage = createChatMessage('user', inputText);
    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    setInputText('');
    setIsLoading(true);

    try {
      // Get AI response
      const aiResponse = await sendChatMessage(inputText, messages);
      const assistantMessage = createChatMessage('assistant', aiResponse);
      const finalMessages = [...updatedMessages, assistantMessage];

      setMessages(finalMessages);
      await saveChatHistory(finalMessages);

      // Scroll to bottom
      setTimeout(() => {
        flatListRef.current?.scrollToEnd({ animated: true });
      }, 100);
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const renderChatBubble = ({ item }: { item: ChatMessage }) => {
    const isUser = item.role === 'user';

    return (
      <View
        className={`flex-row mb-4 ${isUser ? 'justify-end' : 'justify-start'}`}
      >
        <View
          className={`max-w-xs rounded-2xl px-4 py-3 ${
            isUser
              ? 'bg-primary rounded-br-none'
              : 'bg-surface border border-border rounded-bl-none'
          }`}
        >
          <Text
            className={`text-base leading-relaxed ${
              isUser ? 'text-white' : 'text-foreground'
            }`}
          >
            {item.content}
          </Text>
        </View>
      </View>
    );
  };

  return (
    <ScreenContainer className="p-0 flex-1">
      {/* Chat Messages */}
      {messages.length === 0 ? (
        <View className="flex-1 items-center justify-center p-6">
          <IconSymbol size={64} name="sparkles" color={colors.muted} />
          <Text className="text-foreground text-xl font-semibold mt-4 text-center">
            IA Farmacêutica
          </Text>
          <Text className="text-muted text-center mt-2">
            Faça perguntas sobre medicamentos, exames e saúde
          </Text>
          <View className="mt-6 bg-warning/10 border border-warning rounded-lg p-4">
            <Text className="text-xs font-semibold text-warning mb-2">
              ⚠️ IMPORTANTE
            </Text>
            <Text className="text-xs text-muted">
              Esta informação é apenas educacional e não substitui orientação médica profissional. Sempre consulte um médico.
            </Text>
          </View>
        </View>
      ) : (
        <FlatList
          ref={flatListRef}
          data={messages}
          renderItem={renderChatBubble}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ padding: 16, paddingBottom: 24 }}
          onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: true })}
        />
      )}

      {/* Input Area */}
      <View className="border-t border-border bg-background px-4 py-3">
        {isLoading && (
          <View className="flex-row items-center gap-2 mb-3">
            <ActivityIndicator size="small" color={colors.primary} />
            <Text className="text-sm text-muted">IA está digitando...</Text>
          </View>
        )}

        <View className="flex-row items-end gap-2">
          <View className="flex-1 bg-surface border border-border rounded-2xl px-4 py-2">
            <TextInput
              className="text-foreground text-base"
              placeholder="Digite sua pergunta..."
              placeholderTextColor={colors.muted}
              value={inputText}
              onChangeText={setInputText}
              multiline
              maxLength={500}
              editable={!isLoading}
            />
          </View>
          <TouchableOpacity
            className="bg-primary rounded-full p-3"
            onPress={handleSendMessage}
            disabled={isLoading || !inputText.trim()}
            activeOpacity={0.7}
          >
            <IconSymbol size={20} name="paperplane.fill" color="white" />
          </TouchableOpacity>
        </View>
      </View>
    </ScreenContainer>
  );
}
