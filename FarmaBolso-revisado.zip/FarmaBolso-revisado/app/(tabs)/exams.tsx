import { ScrollView, Text, View, FlatList, TouchableOpacity, Modal, TextInput, Pressable } from 'react-native';
import { useState } from 'react';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { useColors } from '@/hooks/use-colors';
import { useExams } from '@/lib/context/exams-context';
import { labReferences, getExamStatus } from '@/lib/services/lab-references';

export default function ExamsScreen() {
  const colors = useColors();
  const router = useRouter();
  const { exams, addExam, removeExam } = useExams();
  const [activeTab, setActiveTab] = useState<'references' | 'myexams'>('references');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedExamId, setSelectedExamId] = useState<string | null>(null);
  const [newExamValue, setNewExamValue] = useState('');
  const [userGender, setUserGender] = useState<'male' | 'female'>('male');

  const handleAddExam = async () => {
    if (!selectedExamId || !newExamValue) return;

    const reference = labReferences.find((r) => r.id === selectedExamId);
    if (!reference) return;

    try {
      await addExam({
        referenceId: selectedExamId,
        value: parseFloat(newExamValue),
        date: new Date().toISOString().split('T')[0],
        gender: userGender,
      });

      setNewExamValue('');
      setSelectedExamId(null);
      setShowAddModal(false);
    } catch (error) {
      console.error('Error adding exam:', error);
    }
  };

  const renderReferenceCard = ({ item }: { item: typeof labReferences[0] }) => (
    <TouchableOpacity
      className="bg-surface rounded-lg p-4 mb-3 border border-border"
      onPress={() => {
        setSelectedExamId(item.id);
        setShowAddModal(true);
      }}
      activeOpacity={0.7}
    >
      <Text className="text-lg font-semibold text-foreground mb-1">
        {item.name}
      </Text>
      <Text className="text-sm text-muted mb-2">
        {item.description}
      </Text>
      <View className="flex-row gap-4">
        <View className="flex-1">
          <Text className="text-xs text-muted">Homens</Text>
          <Text className="text-sm font-semibold text-foreground">
            {item.reference.male.min} - {item.reference.male.max} {item.unit}
          </Text>
        </View>
        <View className="flex-1">
          <Text className="text-xs text-muted">Mulheres</Text>
          <Text className="text-sm font-semibold text-foreground">
            {item.reference.female.min} - {item.reference.female.max} {item.unit}
          </Text>
        </View>
      </View>
      <View className="mt-3 bg-primary rounded-lg py-2 px-4">
        <Text className="text-white text-center font-semibold text-sm">
          Adicionar Meu Valor
        </Text>
      </View>
    </TouchableOpacity>
  );

  const renderMyExamCard = ({ item }: { item: typeof exams[0] }) => {
    const reference = labReferences.find((r) => r.id === item.referenceId);
    if (!reference) return null;

    const status = getExamStatus(item.value, reference, item.gender);
    const statusColor =
      status === 'normal'
        ? colors.success
        : status === 'low'
          ? colors.warning
          : colors.error;

    return (
      <View className="bg-surface rounded-lg p-4 mb-3 border border-border">
        <View className="flex-row justify-between items-start">
          <Text className="text-lg font-semibold text-foreground mb-1 flex-1">
            {reference.name}
          </Text>
          <TouchableOpacity onPress={() => removeExam(item.id)} className="p-1">
            <IconSymbol size={18} name="trash.fill" color={colors.error} />
          </TouchableOpacity>
        </View>
        <View className="flex-row items-center justify-between mb-2">
          <Text className="text-2xl font-bold" style={{ color: statusColor }}>
            {item.value} {reference.unit}
          </Text>
          <View
            className="rounded-full px-3 py-1"
            style={{ backgroundColor: statusColor + '20' }}
          >
            <Text className="text-xs font-semibold" style={{ color: statusColor }}>
              {status === 'normal' ? 'Normal' : status === 'low' ? 'Baixo' : 'Alto'}
            </Text>
          </View>
        </View>
        <Text className="text-xs text-muted mb-2">
          Referência ({item.gender === 'male' ? 'H' : 'M'}): {reference.reference[item.gender as 'male' | 'female'].min} - {reference.reference[item.gender as 'male' | 'female'].max} {reference.unit}
        </Text>
        <Text className="text-sm text-muted">
          {reference.interpretation[status]}
        </Text>
      </View>
    );
  };

  return (
    <ScreenContainer className="p-4">
      {/* Tabs */}
      <View className="flex-row gap-2 mb-4">
        <TouchableOpacity
          className={`flex-1 rounded-lg py-2 px-3 ${
            activeTab === 'references' ? 'bg-primary' : 'bg-surface border border-border'
          }`}
          onPress={() => setActiveTab('references')}
        >
          <Text
            className={`text-center font-semibold ${
              activeTab === 'references' ? 'text-white' : 'text-foreground'
            }`}
          >
            Referências
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          className={`flex-1 rounded-lg py-2 px-3 ${
            activeTab === 'myexams' ? 'bg-primary' : 'bg-surface border border-border'
          }`}
          onPress={() => setActiveTab('myexams')}
        >
          <Text
            className={`text-center font-semibold ${
              activeTab === 'myexams' ? 'text-white' : 'text-foreground'
            }`}
          >
            Meus Exames
          </Text>
        </TouchableOpacity>
      </View>

      {/* Content */}
      <ScrollView className="flex-1">
        {activeTab === 'references' ? (
          labReferences.map((item) => (
            <View key={item.id}>
              {renderReferenceCard({ item })}
            </View>
          ))
        ) : (
          <>
            {exams.length > 0 ? (
              exams.map((item) => (
                <View key={item.id}>
                  {renderMyExamCard({ item })}
                </View>
              ))
            ) : (
              <View className="items-center justify-center py-12">
                <IconSymbol size={48} name="flask.fill" color={colors.muted} />
                <Text className="text-muted mt-4 text-center">
                  Você ainda não adicionou nenhum exame
                </Text>
              </View>
            )}
          </>
        )}
      </ScrollView>

      {/* Floating Action Button for Camera */}
      <TouchableOpacity
        className="absolute bottom-6 right-6 bg-primary rounded-full p-4 shadow-lg"
        onPress={() => router.push('/exam-camera')}
      >
        <IconSymbol size={24} name="camera.fill" color="white" />
      </TouchableOpacity>

      {/* Add Exam Modal */}
      <Modal
        visible={showAddModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowAddModal(false)}
      >
        <View className="flex-1 bg-black/50 justify-end">
          <View className="bg-background rounded-t-2xl p-6">
            <Text className="text-xl font-semibold text-foreground mb-4">
              Adicionar Valor de Exame
            </Text>

            {selectedExamId && labReferences.find((r) => r.id === selectedExamId) && (
              <>
                <Text className="text-sm text-muted mb-2">
                  {labReferences.find((r) => r.id === selectedExamId)?.name}
                </Text>

                {/* Gender Selection */}
                <Text className="text-sm font-semibold text-foreground mb-2">
                  Seu Gênero
                </Text>
                <View className="flex-row gap-2 mb-4">
                  <TouchableOpacity
                    className={`flex-1 rounded-lg py-2 ${
                      userGender === 'male' ? 'bg-primary' : 'bg-surface border border-border'
                    }`}
                    onPress={() => setUserGender('male')}
                  >
                    <Text
                      className={`text-center font-semibold ${
                        userGender === 'male' ? 'text-white' : 'text-foreground'
                      }`}
                    >
                      Masculino
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    className={`flex-1 rounded-lg py-2 ${
                      userGender === 'female' ? 'bg-primary' : 'bg-surface border border-border'
                    }`}
                    onPress={() => setUserGender('female')}
                  >
                    <Text
                      className={`text-center font-semibold ${
                        userGender === 'female' ? 'text-white' : 'text-foreground'
                      }`}
                    >
                      Feminino
                    </Text>
                  </TouchableOpacity>
                </View>

                {/* Value Input */}
                <Text className="text-sm font-semibold text-foreground mb-2">
                  Seu Valor
                </Text>
                <TextInput
                  className="bg-surface border border-border rounded-lg px-3 py-2 text-foreground mb-4"
                  placeholder="Ex: 13.5"
                  placeholderTextColor={colors.muted}
                  value={newExamValue}
                  onChangeText={setNewExamValue}
                  keyboardType="decimal-pad"
                />

                {/* Buttons */}
                <View className="flex-row gap-2">
                  <TouchableOpacity
                    className="flex-1 bg-surface border border-border rounded-lg py-3"
                    onPress={() => setShowAddModal(false)}
                  >
                    <Text className="text-center font-semibold text-foreground">
                      Cancelar
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    className="flex-1 bg-primary rounded-lg py-3"
                    onPress={handleAddExam}
                  >
                    <Text className="text-center font-semibold text-white">
                      Adicionar
                    </Text>
                  </TouchableOpacity>
                </View>
              </>
            )}
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}
