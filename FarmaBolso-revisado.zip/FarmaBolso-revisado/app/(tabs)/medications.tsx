import { ScrollView, Text, View, FlatList, TouchableOpacity, Modal, TextInput, ActivityIndicator } from 'react-native';
import { useState } from 'react';
import { ScreenContainer } from '@/components/screen-container';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { useColors } from '@/hooks/use-colors';
import { useMedications } from '@/lib/context/medications-context';
import { searchMedicationsWithCache, MedicationSearchResult } from '@/lib/services/bulario-service';

export default function MedicationsScreen() {
  const colors = useColors();
  const { medications, addMedication, removeMedication, getInteractions } = useMedications();
  const [showAddModal, setShowAddModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<MedicationSearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedMed, setSelectedMed] = useState<MedicationSearchResult | null>(null);
  
  const [newMedicationDosage, setNewMedicationDosage] = useState('');
  const [newMedicationFrequency, setNewMedicationFrequency] = useState('');

  const interactions = getInteractions();

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    setIsSearching(true);
    try {
      const results = await searchMedicationsWithCache(searchQuery);
      setSearchResults(results);
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setIsSearching(false);
    }
  };

  const handleAddMedication = async () => {
    if (!selectedMed || !newMedicationDosage.trim() || !newMedicationFrequency.trim()) {
      return;
    }

    try {
      await addMedication({
        name: selectedMed.nomeComercial,
        dosage: newMedicationDosage,
        frequency: newMedicationFrequency,
        startDate: new Date().toISOString().split('T')[0],
      });

      resetForm();
      setShowAddModal(false);
    } catch (error) {
      console.error('Error adding medication:', error);
    }
  };

  const resetForm = () => {
    setSearchQuery('');
    setSearchResults([]);
    setSelectedMed(null);
    setNewMedicationDosage('');
    setNewMedicationFrequency('');
  };

  const renderMedicationCard = ({ item }: { item: typeof medications[0] }) => (
    <View className="bg-surface rounded-lg p-4 mb-3 border border-border">
      <View className="flex-row justify-between items-start mb-2">
        <View className="flex-1">
          <Text className="text-lg font-semibold text-foreground">
            {item.name}
          </Text>
          <Text className="text-sm text-muted mt-1">
            Dosagem: {item.dosage}
          </Text>
          <Text className="text-sm text-muted">
            Frequência: {item.frequency}
          </Text>
        </View>
        <TouchableOpacity
          onPress={() => removeMedication(item.id)}
          className="p-2"
        >
          <IconSymbol size={20} name="xmark.circle.fill" color={colors.error} />
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <ScreenContainer className="p-4">
      {/* Alerts Section */}
      {interactions.length > 0 && (
        <View className="bg-error/10 border border-error rounded-lg p-4 mb-4">
          <View className="flex-row items-start gap-3">
            <IconSymbol size={20} name="exclamationmark.triangle.fill" color={colors.error} />
            <View className="flex-1">
              <Text className="font-semibold text-error mb-2">
                Possíveis Interações Detectadas
              </Text>
              {interactions.map((interaction, index) => (
                <View key={index} className="mb-3 pb-3 border-b border-error/20">
                  <Text className="text-sm font-semibold text-foreground mb-1">
                    {interaction.drug1} + {interaction.drug2}
                  </Text>
                  <Text className="text-xs text-muted mb-2">
                    {interaction.description}
                  </Text>
                  <Text className="text-xs font-semibold text-error">
                    ⚠️ {interaction.recommendation}
                  </Text>
                </View>
              ))}
            </View>
          </View>
        </View>
      )}

      {/* Medications List */}
      <ScrollView className="flex-1">
        {medications.length > 0 ? (
          medications.map((item) => (
            <View key={item.id}>
              {renderMedicationCard({ item })}
            </View>
          ))
        ) : (
          <View className="items-center justify-center py-12">
            <IconSymbol size={48} name="pill.fill" color={colors.muted} />
            <Text className="text-muted mt-4 text-center">
              Você ainda não adicionou nenhum medicamento
            </Text>
          </View>
        )}
      </ScrollView>

      {/* Add Button */}
      <TouchableOpacity
        className="absolute bottom-6 right-6 bg-primary rounded-full p-4 shadow-lg"
        onPress={() => setShowAddModal(true)}
      >
        <IconSymbol size={24} name="plus" color="white" />
      </TouchableOpacity>

      {/* Add Medication Modal */}
      <Modal
        visible={showAddModal}
        transparent
        animationType="slide"
        onRequestClose={() => {
          resetForm();
          setShowAddModal(false);
        }}
      >
        <View className="flex-1 bg-black/50 justify-end">
          <View className="bg-background rounded-t-3xl p-6 max-h-[90%]">
            <View className="flex-row justify-between items-center mb-6">
              <Text className="text-2xl font-bold text-foreground">
                Novo Medicamento
              </Text>
              <TouchableOpacity onPress={() => { resetForm(); setShowAddModal(false); }}>
                <IconSymbol size={24} name="xmark" color={colors.muted} />
              </TouchableOpacity>
            </View>

            {!selectedMed ? (
              <>
                <Text className="text-sm font-semibold text-foreground mb-2">
                  Buscar na base da ANVISA
                </Text>
                <View className="flex-row gap-2 mb-4">
                  <View className="flex-1 flex-row items-center bg-surface border border-border rounded-xl px-3 py-2">
                    <IconSymbol size={18} name="magnifyingglass" color={colors.muted} />
                    <TextInput
                      className="flex-1 ml-2 text-foreground"
                      placeholder="Nome do medicamento..."
                      placeholderTextColor={colors.muted}
                      value={searchQuery}
                      onChangeText={setSearchQuery}
                      onSubmitEditing={handleSearch}
                    />
                  </View>
                  <TouchableOpacity 
                    className="bg-primary rounded-xl px-4 justify-center"
                    onPress={handleSearch}
                  >
                    <Text className="text-white font-bold">Buscar</Text>
                  </TouchableOpacity>
                </View>

                {isSearching ? (
                  <ActivityIndicator className="my-8" color={colors.primary} />
                ) : (
                  <ScrollView className="max-h-64 mb-4">
                    {searchResults.map((item) => (
                      <TouchableOpacity
                        key={item.processo}
                        className="p-4 border-b border-border bg-surface/50 mb-1 rounded-lg"
                        onPress={() => setSelectedMed(item)}
                      >
                        <Text className="font-bold text-foreground">{item.nomeComercial}</Text>
                        <Text className="text-xs text-muted">{item.principioAtivo}</Text>
                      </TouchableOpacity>
                    ))}
                    {searchResults.length === 0 && searchQuery !== '' && !isSearching && (
                      <Text className="text-center text-muted py-4">Nenhum resultado encontrado</Text>
                    )}
                  </ScrollView>
                )}
              </>
            ) : (
              <View className="mb-6">
                <View className="bg-primary/10 p-4 rounded-xl border border-primary/20 mb-6">
                  <View className="flex-row justify-between items-start">
                    <View className="flex-1">
                      <Text className="text-lg font-bold text-primary">{selectedMed.nomeComercial}</Text>
                      <Text className="text-sm text-muted">{selectedMed.principioAtivo}</Text>
                    </View>
                    <TouchableOpacity onPress={() => setSelectedMed(null)}>
                      <Text className="text-primary font-semibold">Alterar</Text>
                    </TouchableOpacity>
                  </View>
                </View>

                <Text className="text-sm font-semibold text-foreground mb-2">
                  Dosagem
                </Text>
                <TextInput
                  className="bg-surface border border-border rounded-xl px-4 py-3 text-foreground mb-4"
                  placeholder="Ex: 500mg ou 1 comprimido"
                  placeholderTextColor={colors.muted}
                  value={newMedicationDosage}
                  onChangeText={setNewMedicationDosage}
                />

                <Text className="text-sm font-semibold text-foreground mb-2">
                  Frequência
                </Text>
                <TextInput
                  className="bg-surface border border-border rounded-xl px-4 py-3 text-foreground mb-4"
                  placeholder="Ex: 8/8h ou 2x ao dia"
                  placeholderTextColor={colors.muted}
                  value={newMedicationFrequency}
                  onChangeText={setNewMedicationFrequency}
                />

                <TouchableOpacity
                  className={`rounded-xl py-4 mt-2 ${
                    newMedicationDosage && newMedicationFrequency ? 'bg-primary' : 'bg-muted/30'
                  }`}
                  onPress={handleAddMedication}
                  disabled={!newMedicationDosage || !newMedicationFrequency}
                >
                  <Text className="text-center font-bold text-white text-lg">
                    Confirmar Adição
                  </Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}
