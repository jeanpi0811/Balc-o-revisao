import { ScrollView, Text, View, TouchableOpacity, ActivityIndicator, Linking } from 'react-native';
import { useState, useEffect } from 'react';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { useColors } from '@/hooks/use-colors';
import { getMedicationDetail, getBulaLink, MedicationDetail } from '@/lib/services/bulario-service';

export default function MedicineDetailsScreen() {
  const { processo, nome } = useLocalSearchParams<{ processo: string; nome: string }>();
  const colors = useColors();
  const router = useRouter();
  const [detail, setDetail] = useState<MedicationDetail | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function loadDetail() {
      if (!processo) return;
      try {
        const data = await getMedicationDetail(processo);
        setDetail(data);
      } catch (error) {
        console.error('Error loading detail:', error);
      } finally {
        setIsLoading(false);
      }
    }
    loadDetail();
  }, [processo]);

  const handleOpenBula = async () => {
    if (!detail?.idBulaPacienteProtegido) return;
    try {
      const url = await getBulaLink(detail.idBulaPacienteProtegido);
      if (url) {
        await Linking.openURL(url);
      }
    } catch (error) {
      console.error('Error opening bula:', error);
    }
  };

  if (isLoading) {
    return (
      <ScreenContainer className="items-center justify-center">
        <ActivityIndicator size="large" color={colors.primary} />
        <Text className="text-muted mt-2">Carregando detalhes...</Text>
      </ScreenContainer>
    );
  }

  if (!detail) {
    return (
      <ScreenContainer className="items-center justify-center p-4">
        <IconSymbol size={48} name="exclamationmark.triangle.fill" color={colors.error} />
        <Text className="text-foreground text-lg font-semibold mt-4">Erro ao carregar</Text>
        <Text className="text-muted text-center mt-2">Não foi possível encontrar os detalhes deste medicamento.</Text>
        <TouchableOpacity 
          className="mt-6 bg-primary rounded-lg py-3 px-6"
          onPress={() => router.back()}
        >
          <Text className="text-white font-semibold">Voltar</Text>
        </TouchableOpacity>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer>
      <ScrollView className="flex-1 p-4">
        <View className="flex-row items-center justify-between mb-6">
          <TouchableOpacity onPress={() => router.back()} className="p-2 -ml-2">
            <IconSymbol size={24} name="chevron.left" color={colors.primary} />
          </TouchableOpacity>
          <Text className="text-xl font-bold text-foreground flex-1 ml-2" numberOfLines={1}>
            {detail.nomeComercial}
          </Text>
        </View>

        <View className="bg-surface rounded-xl p-4 border border-border mb-6">
          <Text className="text-sm text-muted mb-1">Princípio Ativo</Text>
          <Text className="text-lg font-semibold text-foreground mb-4">{detail.principioAtivo}</Text>
          
          <Text className="text-sm text-muted mb-1">Laboratório</Text>
          <Text className="text-base text-foreground mb-4">{detail.laboratorio}</Text>

          <Text className="text-sm text-muted mb-1">Número do Processo</Text>
          <Text className="text-sm text-foreground">{detail.processo}</Text>
        </View>

        {detail.idBulaPacienteProtegido && (
          <TouchableOpacity 
            className="bg-primary flex-row items-center justify-center rounded-xl py-4 mb-6 gap-2"
            onPress={handleOpenBula}
          >
            <IconSymbol size={20} name="doc.text.fill" color="white" />
            <Text className="text-white font-bold text-lg">Visualizar Bula Completa (PDF)</Text>
          </TouchableOpacity>
        )}

        <View className="gap-6 pb-8">
          <Section title="Indicações" content={detail.indicacoes} />
          <Section title="Posologia" content={detail.posologia} />
          <Section title="Contraindicações" content={detail.contraindicacoes} />
          <Section title="Efeitos Colaterais" content={detail.efeitos_colaterais} />
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

function Section({ title, content }: { title: string; content?: string }) {
  if (!content) return null;
  return (
    <View>
      <Text className="text-lg font-bold text-primary mb-2">{title}</Text>
      <Text className="text-base text-foreground leading-6">{content}</Text>
    </View>
  );
}
