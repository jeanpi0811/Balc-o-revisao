import { useState, useRef } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, Image, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { useColors } from '@/hooks/use-colors';

export default function ExamCameraScreen() {
  const colors = useColors();
  const router = useRouter();
  const [isCapturing, setIsCapturing] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);

  const takePicture = async () => {
    setIsCapturing(true);
    // Simulação de captura e processamento OCR
    setTimeout(() => {
      setIsCapturing(false);
      setCapturedImage('https://via.placeholder.com/600x800.png?text=Exame+Capturado');
    }, 2000);
  };

  const handleConfirm = () => {
    // No futuro, aqui passaria os dados extraídos pelo OCR para a tela de exames
    router.back();
  };

  return (
    <ScreenContainer className="bg-black">
      {!capturedImage ? (
        <View className="flex-1">
          {/* Header */}
          <View className="flex-row justify-between items-center p-6 mt-4">
            <TouchableOpacity onPress={() => router.back()} className="p-2 bg-white/20 rounded-full">
              <IconSymbol size={24} name="xmark" color="white" />
            </TouchableOpacity>
            <Text className="text-white font-bold text-lg">Digitalizar Exame</Text>
            <View className="w-10" />
          </View>

          {/* Camera Viewport Placeholder */}
          <View className="flex-1 items-center justify-center border-2 border-dashed border-white/30 m-6 rounded-3xl">
            <View className="w-64 h-96 border-2 border-primary rounded-lg items-center justify-center">
              <Text className="text-white/50 text-center px-8">Posicione o resultado do exame dentro desta área</Text>
            </View>
          </View>

          {/* Controls */}
          <View className="p-12 items-center">
            <TouchableOpacity 
              className="w-20 h-20 bg-white rounded-full items-center justify-center border-4 border-white/30"
              onPress={takePicture}
              disabled={isCapturing}
            >
              {isCapturing ? (
                <ActivityIndicator color={colors.primary} />
              ) : (
                <View className="w-16 h-16 bg-white rounded-full border-2 border-primary" />
              )}
            </TouchableOpacity>
            <Text className="text-white mt-4 font-semibold">Tocar para capturar</Text>
          </View>
        </View>
      ) : (
        <View className="flex-1">
          <Image source={{ uri: capturedImage }} className="flex-1" resizeMode="contain" />
          
          <View className="absolute bottom-0 left-0 right-0 p-8 bg-black/80">
            <Text className="text-white text-center mb-6 font-semibold">
              Exame capturado com sucesso! No momento, o OCR está em fase de testes. 
              Por favor, verifique os valores manualmente.
            </Text>
            <View className="flex-row gap-4">
              <TouchableOpacity 
                className="flex-1 bg-white/20 py-4 rounded-xl"
                onPress={() => setCapturedImage(null)}
              >
                <Text className="text-white text-center font-bold">Repetir</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                className="flex-1 bg-primary py-4 rounded-xl"
                onPress={handleConfirm}
              >
                <Text className="text-white text-center font-bold">Continuar</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      )}
    </ScreenContainer>
  );
}
