import { ScrollView, Text, View, TouchableOpacity, Image } from 'react-native';
import { useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ScreenContainer } from '@/components/screen-container';
import { useColors } from '@/hooks/use-colors';

const ONBOARDING_SEEN_KEY = '@farma_bolso_onboarding_seen';

export default function OnboardingScreen() {
  const colors = useColors();
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    checkOnboardingStatus();
  }, []);

  const checkOnboardingStatus = async () => {
    try {
      const seen = await AsyncStorage.getItem(ONBOARDING_SEEN_KEY);
      if (seen) {
        router.replace('/(tabs)');
      }
    } catch (error) {
      console.error('Error checking onboarding:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleGetStarted = async () => {
    try {
      await AsyncStorage.setItem(ONBOARDING_SEEN_KEY, 'true');
      router.replace('/(tabs)');
    } catch (error) {
      console.error('Error saving onboarding status:', error);
    }
  };

  if (isLoading) {
    return (
      <ScreenContainer className="items-center justify-center">
        <Text className="text-foreground">Carregando...</Text>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="p-0">
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Hero Section with Icon */}
        <View className="flex-1 items-center justify-center bg-gradient-to-b from-primary/10 to-background pt-12 pb-8">
          <View className="w-48 h-48 rounded-3xl overflow-hidden shadow-lg mb-8">
            <Image
              source={require('@/assets/images/icon.png')}
              style={{ width: '100%', height: '100%' }}
              resizeMode="cover"
            />
          </View>

          <Text className="text-4xl font-bold text-foreground text-center mb-3 px-4">
            Farma Bolso
          </Text>

          <Text className="text-lg text-muted text-center px-6 mb-8">
            Seu assistente farmacêutico pessoal no bolso
          </Text>
        </View>

        {/* Features Section */}
        <View className="px-6 py-8 space-y-6">
          <FeatureCard
            icon="📋"
            title="Bulas de Medicamentos"
            description="Acesse todas as bulas de medicamentos disponíveis na ANVISA"
            color={colors.primary}
          />

          <FeatureCard
            icon="🧪"
            title="Exames Laboratoriais"
            description="Consulte valores de referência e analise seus resultados"
            color={colors.primary}
          />

          <FeatureCard
            icon="💊"
            title="Meus Medicamentos"
            description="Gerencie seus medicamentos e detecte interações perigosas"
            color={colors.primary}
          />

          <FeatureCard
            icon="🤖"
            title="IA Farmacêutica"
            description="Tire dúvidas com nosso assistente de IA especializado"
            color={colors.primary}
          />

          <FeatureCard
            icon="🔒"
            title="Dados Seguros"
            description="Todos os dados são armazenados localmente no seu dispositivo"
            color={colors.primary}
          />
        </View>

        {/* CTA Section */}
        <View className="px-6 py-8">
          <TouchableOpacity
            className="bg-primary rounded-2xl py-4 px-6 shadow-lg"
            onPress={handleGetStarted}
            activeOpacity={0.8}
          >
            <Text className="text-white text-center font-bold text-lg">
              Começar Agora
            </Text>
          </TouchableOpacity>

          <Text className="text-xs text-muted text-center mt-6">
            Ao continuar, você concorda com nossa política de privacidade e LGPD
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

function FeatureCard({
  icon,
  title,
  description,
  color,
}: {
  icon: string;
  title: string;
  description: string;
  color: string;
}) {
  const colors = useColors();

  return (
    <View className="flex-row items-start gap-4 bg-surface rounded-2xl p-4 border border-border">
      <Text className="text-4xl">{icon}</Text>
      <View className="flex-1">
        <Text className="text-lg font-semibold text-foreground mb-1">
          {title}
        </Text>
        <Text className="text-sm text-muted leading-relaxed">
          {description}
        </Text>
      </View>
    </View>
  );
}
