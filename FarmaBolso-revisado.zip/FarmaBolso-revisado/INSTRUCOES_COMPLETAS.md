# 📱 Farma Bolso - Documentação Completa

## 🎯 Visão Geral

**Farma Bolso** é um aplicativo farmacêutico educacional que fornece informações sobre medicamentos, exames laboratoriais, interações medicamentosas e assistência de IA. O projeto foi unificado e expandido com novas funcionalidades, incluindo sistema de assinaturas, painel administrativo e cadastro completo de usuários.

**Versão:** 2.0.0  
**Data:** Abril 2026  
**Status:** Pronto para desenvolvimento e testes

---

## 📋 Sumário de Melhorias Implementadas

### 1. **Aba Home (Nova)**
- Resumo personalizado com saudação do usuário
- Status de assinatura (Gratuito/Premium)
- Estatísticas de uso diário (Bulas, Exames, IA)
- Atalhos rápidos para as principais funcionalidades
- Dica de saúde educacional

### 2. **Aba Bulas (Melhorada)**
- Integração com API de bulas (bulario-api)
- Busca funcional por nome de medicamento
- Fallback para respostas locais em caso de falha
- Detalhes completos: indicações, posologia, contraindicações, efeitos colaterais
- Link para download de PDF da bula

### 3. **Aba Exames (Expandida)**
- **50+ referências de exames laboratoriais** (antes eram 13)
- Categorias: Hematologia, Bioquímica, Lipídios, Tireoide, Fígado, Rins, Coagulação
- Valores de referência por gênero (Homem/Mulher)
- Interpretação clínica detalhada
- Significância clínica e notas importantes
- Baseado em literatura médica brasileira (PNCQ, SBPC, protocolos internacionais)

### 4. **Aba IA (Funcional)**
- Integração com **Groq API** (gratuita e rápida)
- Respostas detalhadas sobre medicamentos, exames e saúde
- Fallback para respostas locais sem conexão
- Chat com histórico persistente
- Avisos educacionais em todas as respostas

### 5. **Aba Configurações (Completa)**
- **Cadastro Expandido** com 12+ campos:
  - Nome, Email, Data de Nascimento
  - Telefone, CPF
  - Endereço (Rua, Cidade, Estado, CEP)
  - Contato de Emergência
  - Alergias
  - Doenças Crônicas
  - Medicamentos em uso

- **Sistema de Assinaturas:**
  - Plano Gratuito: 3 consultas/dia
  - Plano Mensal: R$ 9,90 (Consultas ilimitadas)
  - Plano Trimestral: R$ 24,90 (Economiza 16%)
  - Plano Semestral: R$ 49,90 (Economiza 28%)
  - Plano Anual: R$ 99,90 (Economiza 33%)

- **Painel Administrativo:**
  - Acesso com senha (padrão: `admin123`)
  - Gerenciar senha de administrador
  - Visualizar estatísticas (em desenvolvimento)
  - Gerenciar usuários (em desenvolvimento)
  - Apenas para usuários autenticados como admin

### 6. **Banco de Dados Expandido**
Novas tabelas criadas em `drizzle/schema.ts`:
- `userProfiles` - Dados completos do paciente/usuário
- `subscriptions` - Gerenciamento de assinaturas
- `dailyUsage` - Controle de limite de consultas diárias
- `paymentHistory` - Histórico de pagamentos
- `auditLogs` - Logs de ações administrativas
- `systemSettings` - Configurações do sistema

### 7. **Serviços Novos**
- `subscription-service.ts` - Gerenciamento de assinaturas e quotas
- `ai-service-improved.ts` - IA com Groq API e fallback local

---

## 🚀 Como Usar

### Instalação

```bash
# Clonar ou extrair o projeto
cd AppFarmaBolso_Unificado

# Instalar dependências
pnpm install

# Configurar variáveis de ambiente
cp .env.example .env

# Executar migrações do banco de dados
pnpm db:push
```

### Variáveis de Ambiente

Crie um arquivo `.env` na raiz do projeto:

```env
# Banco de Dados
DATABASE_URL=mysql://user:password@localhost:3306/farma_bolso

# Groq API (Opcional - para IA melhorada)
GROQ_API_KEY=seu_groq_api_key_aqui

# Manus OAuth (Se usando)
MANUS_CLIENT_ID=seu_client_id
MANUS_CLIENT_SECRET=seu_client_secret
```

### Executar em Desenvolvimento

```bash
# Iniciar servidor de desenvolvimento
pnpm dev

# Em outro terminal, iniciar Metro (para React Native)
pnpm dev:metro

# Para iOS
pnpm ios

# Para Android
pnpm android

# Para Web
pnpm web
```

---

## 🔐 Acesso de Administrador

### Primeira Vez
1. Vá para **Configurações** → **Suporte e Conta**
2. Clique em **Acesso de Administrador**
3. Digite a senha padrão: `admin123`
4. Após login, você terá acesso ao painel admin

### Alterar Senha de Admin
1. Estando logado como admin
2. Vá para **Configurações** → **Administração** → **Gerenciar Senha Admin**
3. Digite a nova senha (mínimo 6 caracteres)

### Funcionalidades Admin
- Visualizar estatísticas de uso
- Gerenciar usuários
- Alterar configurações do sistema
- Ver logs de auditoria

---

## 💳 Sistema de Assinaturas

### Limite de Consultas Diárias (Gratuito)

O plano gratuito permite **3 consultas diárias**, contando:
- Buscas de bulas
- Consultas de exames
- Perguntas para IA

O limite é resetado diariamente à meia-noite.

### Upgrade para Plano Pago

1. Vá para **Configurações** → **Assinatura**
2. Clique em **Upgrade**
3. Selecione o plano desejado
4. **Em produção:** Será redirecionado para PagSeguro para pagamento

### Integração PagSeguro (Implementação)

Para integrar com PagSeguro em produção:

```typescript
// server/routers/subscription.ts
import axios from 'axios';

export const pagseguroRouter = createTRPCRouter({
  createSubscription: protectedProcedure
    .input(z.object({ planType: z.string() }))
    .mutation(async ({ input, ctx }) => {
      // Criar assinatura no PagSeguro
      const response = await axios.post(
        'https://api.pagseguro.com/subscriptions',
        {
          plan: mapPlanToPaymentPlan(input.planType),
          customer: {
            name: ctx.user.name,
            email: ctx.user.email,
          },
        },
        {
          headers: {
            'Authorization': `Bearer ${process.env.PAGSEGURO_API_KEY}`,
          },
        }
      );

      // Salvar no banco de dados
      await db.subscriptions.create({
        userId: ctx.user.id,
        planType: input.planType,
        pagseguroSubscriptionId: response.data.id,
        status: 'active',
      });

      return response.data;
    }),
});
```

---

## 📊 Estrutura de Dados

### UserProfile
```typescript
{
  id: number;
  userId: number;
  dateOfBirth?: string;
  gender?: 'male' | 'female' | 'other';
  phone?: string;
  cpf?: string;
  address?: string;
  city?: string;
  state?: string;
  zipCode?: string;
  emergencyContact?: string;
  emergencyPhone?: string;
  allergies?: string;
  chronicDiseases?: string;
  medications?: string;
}
```

### Subscription
```typescript
{
  id: number;
  userId: number;
  planType: 'free' | 'monthly' | 'quarterly' | 'semiannual' | 'annual';
  status: 'active' | 'inactive' | 'cancelled' | 'expired';
  startDate: Date;
  endDate?: Date;
  renewalDate?: Date;
  pagseguroSubscriptionId?: string;
}
```

### DailyUsage
```typescript
{
  id: number;
  userId: number;
  date: string; // YYYY-MM-DD
  bulasSearchCount: number;
  examsSearchCount: number;
  aiQueriesCount: number;
  totalCount: number;
}
```

---

## 🔬 Referências de Exames

O app agora inclui **50+ exames laboratoriais** com:
- Valores de referência por gênero
- Interpretação clínica
- Significância clínica
- Notas importantes

### Categorias:
1. **Hematologia** - Hemoglobina, Hematócrito, Leucócitos, Plaquetas, MCH, MCHC, RDW
2. **Bioquímica** - Glicemia, HbA1c, Creatinina, Ureia, Eletrólitos (Na, K, Ca, P, Mg)
3. **Lipídios** - Colesterol Total, LDL, HDL, Triglicerídeos, VLDL
4. **Tireoide** - TSH, T4 Livre, T3 Livre, Anti-TPO
5. **Fígado** - AST, ALT, GGT, Bilirrubina, Albumina, Proteína Total
6. **Rins** - Creatinina, Ureia, TFG
7. **Coagulação** - PT/INR, APPT

---

## 🤖 Integração com Groq API

### Configurar Groq API

1. Acesse [console.groq.com](https://console.groq.com)
2. Crie uma conta gratuita
3. Gere uma chave de API
4. Adicione ao `.env`:
   ```env
   GROQ_API_KEY=sua_chave_aqui
   ```

### Modelos Disponíveis
- `mixtral-8x7b-32768` (Padrão - Rápido e gratuito)
- `llama-2-70b-chat`
- `gemma-7b-it`

### Limite Gratuito
- 30 requisições por minuto
- 14.400 requisições por dia

---

## 📱 Abas do Aplicativo

| Aba | Ícone | Descrição |
|-----|-------|-----------|
| **Home** | 🏠 | Resumo, atalhos e status de assinatura |
| **Bulas** | 📖 | Busca e consulta de bulas de medicamentos |
| **Exames** | 🧪 | Referências de exames laboratoriais |
| **Medicamentos** | 💊 | Gerenciamento de medicamentos em uso |
| **IA** | ✨ | Chat com assistente farmacêutico |
| **Configurações** | ⚙️ | Perfil, assinatura, admin e preferências |

---

## 🔄 Fluxo de Uso Típico

### Usuário Gratuito
1. Abre o app → Vê a aba **Home**
2. Consulta uma bula → Conta como 1 consulta
3. Verifica um exame → Conta como 1 consulta
4. Faz uma pergunta para IA → Conta como 1 consulta
5. Atingiu 3 consultas → Vê mensagem para upgrade

### Usuário Premium
1. Mesmo fluxo, mas **sem limite de consultas**
2. Acesso a relatórios de saúde
3. Suporte prioritário

### Administrador
1. Login com senha admin
2. Acessa painel de administração
3. Visualiza estatísticas
4. Gerencia usuários

---

## 🐛 Troubleshooting

### Erro: "API de bulas não disponível"
- Verifique conexão com internet
- A API fallback local será usada automaticamente

### Erro: "Limite de consultas atingido"
- Espere até meia-noite (reset automático)
- Ou faça upgrade para plano pago

### Erro: "Senha de admin incorreta"
- Senha padrão: `admin123`
- Se esqueceu, limpe dados do app e reinicie

### Erro: "Groq API não configurada"
- Adicione `GROQ_API_KEY` ao `.env`
- Ou use respostas locais (funcionam sem chave)

---

## 📝 Notas Importantes

### Avisos Legais
- ⚠️ **O app é educacional**, não substitui consulta médica
- ⚠️ **Sempre consulte um profissional** para diagnóstico e tratamento
- ⚠️ **Dados são armazenados localmente** (respeita LGPD)

### Dados de Teste
- **Email:** teste@farmabolso.com.br
- **Senha Admin:** admin123
- **Plano Padrão:** Gratuito (3 consultas/dia)

### Próximas Melhorias
- [ ] Integração real com PagSeguro
- [ ] Notificações de lembretes de medicamentos
- [ ] Exportação de relatórios de saúde
- [ ] Sincronização com prontuário eletrônico
- [ ] Integração com wearables
- [ ] Modo offline completo

---

## 📞 Suporte

**Email:** suporte@farmabolso.com.br  
**Versão:** 2.0.0  
**Última Atualização:** Abril 2026

---

## 📄 Licença

Este projeto é fornecido como está para fins educacionais e de desenvolvimento.

---

## ✅ Checklist de Implementação

- [x] Aba Home com resumo e atalhos
- [x] Cadastro completo de usuário (12+ campos)
- [x] Sistema de assinaturas (5 planos)
- [x] Limite de 3 consultas diárias gratuitas
- [x] Painel administrativo com senha
- [x] Banco de dados expandido
- [x] 50+ referências de exames
- [x] IA com Groq API e fallback local
- [x] Integração com bulas (API)
- [x] LGPD e privacidade
- [x] Documentação completa
- [ ] Integração PagSeguro (em desenvolvimento)
- [ ] Notificações (em desenvolvimento)
- [ ] Relatórios de saúde (em desenvolvimento)

---

**Desenvolvido com ❤️ para melhorar o acesso à informação farmacêutica de qualidade.**
